#ifndef UI_COMPONENTS_HPP
#define UI_COMPONENTS_HPP

#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Tabs.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Input.H>
#include <FL/Fl_Int_Input.H>
#include <FL/Fl_Float_Input.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Text_Display.H>
#include <FL/Fl_Text_Buffer.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Choice.H>
#include <FL/Fl_Check_Button.H>

#include "backend_interface.hpp"
#include <vector>
#include <string>
#include <sstream>
#include <algorithm>

// Forward declaration
class HarmoniaBackend;

/**
 * @brief A basic pitch-class selector widget using buttons.
 */
class PitchClassSelector : public Fl_Group {
public:
    PitchClassSelector(int x, int y, int w, int h, const char* l = 0)
        : Fl_Group(x, y, w, h, l) {
        
        int btn_w = w / 12;
        const char* labels[] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
        
        begin();
        for (int i = 0; i < 12; ++i) {
            buttons[i] = new Fl_Check_Button(x + i * btn_w, y, btn_w, h, labels[i]);
            buttons[i]->type(FL_TOGGLE_BUTTON);
        }
        end();
    }

    std::vector<int> get_selected_pcs() const {
        std::vector<int> pcs;
        for (int i = 0; i < 12; ++i) {
            if (buttons[i]->value()) {
                pcs.push_back(i);
            }
        }
        return pcs;
    }

    void set_selected_pcs(const std::vector<int>& pcs) {
        for (int i = 0; i < 12; ++i) {
            buttons[i]->value(0); // Clear all first
        }
        for (int pc : pcs) {
            if (pc >= 0 && pc < 12) {
                buttons[pc]->value(1);
            }
        }
    }

private:
    Fl_Check_Button* buttons[12];
};

/**
 * @brief Base class for each tab/module in the UI.
 */
class ModuleTab : public Fl_Group {
public:
    ModuleTab(int x, int y, int w, int h, const char* l, HarmoniaBackend* backend)
        : Fl_Group(x, y, w, h, l), backend(backend) {
        
        begin();
        output_buffer = new Fl_Text_Buffer();
        output_display = new Fl_Text_Display(x + 10, y + h - 210, w - 20, 200, "Analysis Result");
        output_display->buffer(output_buffer);
        output_display->textfont(FL_COURIER);
        output_display->textsize(12);
        output_display->box(FL_DOWN_BOX);
        end();
    }

protected:
    HarmoniaBackend* backend;
    Fl_Text_Buffer* output_buffer;
    Fl_Text_Display* output_display;

    void update_output(const std::string& text) {
        output_buffer->text(text.c_str());
    }
};

/**
 * @brief Tab for Psychoacoustic Analysis.
 */
class PsychoacousticTab : public ModuleTab {
public:
    PsychoacousticTab(int x, int y, int w, int h, HarmoniaBackend* backend)
        : ModuleTab(x, y, w, h, "Psychoacoustics", backend) {
        
        begin();
        int current_y = y + 40;
        
        new Fl_Box(x + 10, current_y, 100, 25, "Pitch Classes:");
        pc_selector = new PitchClassSelector(x + 120, current_y, w - 140, 25);
        
        current_y += 35;
        edo_input = new Fl_Int_Input(x + 120, current_y, 60, 25, "EDO:");
        edo_input->value("12");
        
        octave_input = new Fl_Int_Input(x + 240, current_y, 60, 25, "Octave:");
        octave_input->value("4");
        
        current_y += 45;
        analyze_btn = new Fl_Button(x + 10, current_y, 180, 30, "Analyze Psychoacoustics");
        analyze_btn->callback(analyze_cb, this);
        
        im_analyze_btn = new Fl_Button(x + 200, current_y, 200, 30, "Intermodulation Analysis");
        im_analyze_btn->callback(im_analyze_cb, this);
        
        end();
    }

private:
    PitchClassSelector* pc_selector;
    Fl_Int_Input* edo_input;
    Fl_Int_Input* octave_input;
    Fl_Button* analyze_btn;
    Fl_Button* im_analyze_btn;

    static void analyze_cb(Fl_Widget*, void* data) {
        auto self = (PsychoacousticTab*)data;
        std::vector<int> pcs = self->pc_selector->get_selected_pcs();
        if (pcs.empty()) return;
        
        std::stringstream ss;
        ss << "{\"cmd\": \"psychoacoustic_analysis\", \"pcs\": [";
        for (size_t i = 0; i < pcs.size(); ++i) {
            ss << pcs[i] << (i == pcs.size() - 1 ? "" : ", ");
        }
        ss << "], \"edo\": " << self->edo_input->value() << ", \"octave\": " << self->octave_input->value() << "}";
        
        std::string result = self->backend->send_command(ss.str());
        self->update_output(result);
    }

    static void im_analyze_cb(Fl_Widget*, void* data) {
        auto self = (PsychoacousticTab*)data;
        std::vector<int> pcs = self->pc_selector->get_selected_pcs();
        if (pcs.empty()) return;
        
        std::stringstream ss;
        ss << "{\"cmd\": \"intermodulation_analysis\", \"pcs\": [";
        for (size_t i = 0; i < pcs.size(); ++i) {
            ss << pcs[i] << (i == pcs.size() - 1 ? "" : ", ");
        }
        ss << "], \"edo\": " << self->edo_input->value() << ", \"octave\": " << self->octave_input->value() << "}";
        
        std::string result = self->backend->send_command(ss.str());
        self->update_output(result);
    }
};

/**
 * @brief Tab for Functional Analysis.
 */
class FunctionalTab : public ModuleTab {
public:
    FunctionalTab(int x, int y, int w, int h, HarmoniaBackend* backend)
        : ModuleTab(x, y, w, h, "Functional Theory", backend) {
        
        begin();
        int current_y = y + 40;
        
        new Fl_Box(x + 10, current_y, 100, 25, "Chord PCs:");
        pc_selector = new PitchClassSelector(x + 120, current_y, w - 140, 25);
        
        current_y += 35;
        key_input = new Fl_Int_Input(x + 120, current_y, 60, 25, "Key (0-11):");
        key_input->value("0");
        
        edo_input = new Fl_Int_Input(x + 240, current_y, 60, 25, "EDO:");
        edo_input->value("12");
        
        current_y += 45;
        analyze_btn = new Fl_Button(x + 10, current_y, 150, 30, "Analyze Chord");
        analyze_btn->callback(analyze_cb, this);
        
        end();
    }

private:
    PitchClassSelector* pc_selector;
    Fl_Int_Input* key_input;
    Fl_Int_Input* edo_input;
    Fl_Button* analyze_btn;

    static void analyze_cb(Fl_Widget*, void* data) {
        auto self = (FunctionalTab*)data;
        std::vector<int> pcs = self->pc_selector->get_selected_pcs();
        if (pcs.empty()) return;
        
        std::stringstream ss;
        ss << "{\"cmd\": \"analyze_chord\", \"pcs\": [";
        for (size_t i = 0; i < pcs.size(); ++i) {
            ss << pcs[i] << (i == pcs.size() - 1 ? "" : ", ");
        }
        ss << "], \"key\": " << self->key_input->value() << ", \"edo\": " << self->edo_input->value() << "}";
        
        std::string result = self->backend->send_command(ss.str());
        self->update_output(result);
    }
};

/**
 * @brief Tab for Modulation & Pivot Search.
 */
class ModulationTab : public ModuleTab {
public:
    ModulationTab(int x, int y, int w, int h, HarmoniaBackend* backend)
        : ModuleTab(x, y, w, h, "Modulation", backend) {
        
        begin();
        int current_y = y + 40;
        
        key_from_input = new Fl_Int_Input(x + 120, current_y, 60, 25, "Key From:");
        key_from_input->value("0");
        
        key_to_input = new Fl_Int_Input(x + 240, current_y, 60, 25, "Key To:");
        key_to_input->value("7");
        
        current_y += 35;
        edo_input = new Fl_Int_Input(x + 120, current_y, 60, 25, "EDO:");
        edo_input->value("12");
        
        current_y += 45;
        search_btn = new Fl_Button(x + 10, current_y, 150, 30, "Search Pivots");
        search_btn->callback(search_cb, this);
        
        end();
    }

private:
    Fl_Int_Input* key_from_input;
    Fl_Int_Input* key_to_input;
    Fl_Int_Input* edo_input;
    Fl_Button* search_btn;

    static void search_cb(Fl_Widget*, void* data) {
        auto self = (ModulationTab*)data;
        std::stringstream ss;
        ss << "{\"cmd\": \"pivot_search\", \"key_from\": " << self->key_from_input->value() 
           << ", \"key_to\": " << self->key_to_input->value() << ", \"edo\": " << self->edo_input->value() << "}";
        
        std::string result = self->backend->send_command(ss.str());
        self->update_output(result);
    }
};

/**
 * @brief Tab for Arpeggio & Scale Exploration.
 */
class ArpeggioTab : public ModuleTab {
public:
    ArpeggioTab(int x, int y, int w, int h, HarmoniaBackend* backend)
        : ModuleTab(x, y, w, h, "Arpeggios & Scales", backend) {
        
        begin();
        int current_y = y + 40;
        
        root_input = new Fl_Int_Input(x + 120, current_y, 60, 25, "Root (0-11):");
        root_input->value("0");
        
        edo_input = new Fl_Int_Input(x + 240, current_y, 60, 25, "EDO:");
        edo_input->value("12");
        
        current_y += 35;
        type_choice = new Fl_Choice(x + 120, current_y, 150, 25, "Type:");
        type_choice->add("Major");
        type_choice->add("Minor");
        type_choice->add("Dominant 7th");
        type_choice->add("Diminished 7th");
        type_choice->add("Major Pentatonic");
        type_choice->add("Minor Pentatonic");
        type_choice->value(0);
        
        current_y += 45;
        generate_btn = new Fl_Button(x + 10, current_y, 180, 30, "Generate Arpeggio/Scale");
        generate_btn->callback(generate_cb, this);
        
        end();
    }

private:
    Fl_Int_Input* root_input;
    Fl_Int_Input* edo_input;
    Fl_Choice* type_choice;
    Fl_Button* generate_btn;

    static void generate_cb(Fl_Widget*, void* data) {
        auto self = (ArpeggioTab*)data;
        std::stringstream ss;
        std::string type_str = self->type_choice->text();
        
        // This part would need more sophisticated mapping to backend functions
        // For now, we'll simulate a generic 

        // In a full implementation, this would call a backend function to generate the arpeggio/scale.
        int root_pc = std::stoi(self->root_input->value());

        int edo = std::stoi(self->edo_input->value());

        std::vector<int> generated_pcs;
        std::string type = self->type_choice->text();

        if (type == "Major") {
            generated_pcs = {0, 4, 7}; // Major Triad
        } else if (type == "Minor") {
            generated_pcs = {0, 3, 7}; // Minor Triad
        } else if (type == "Dominant 7th") {
            generated_pcs = {0, 4, 7, 10}; // Dominant 7th
        } else if (type == "Diminished 7th") {
            generated_pcs = {0, 3, 6, 9}; // Diminished 7th
        } else if (type == "Major Pentatonic") {
            generated_pcs = {0, 2, 4, 7, 9}; // Major Pentatonic
        } else if (type == "Minor Pentatonic") {
            generated_pcs = {0, 3, 5, 7, 10}; // Minor Pentatonic
        }
        
        std::stringstream output_ss;
        output_ss << "Generated " << type << " Arpeggio/Scale (Root: " << root_pc << ", EDO: " << edo << "):\n";
        output_ss << "Pitch Classes: ";
        for (size_t i = 0; i < generated_pcs.size(); ++i) {
            output_ss << (root_pc + generated_pcs[i]) % edo << (i == generated_pcs.size() - 1 ? "" : ", ");
        }
        output_ss << "\n";

        self->update_output(output_ss.str());
    }
};

/**
 * @brief Tab for Progression Builder.
 */
class ProgressionBuilderTab : public ModuleTab {
public:
    ProgressionBuilderTab(int x, int y, int w, int h, HarmoniaBackend* backend)
        : ModuleTab(x, y, w, h, "Progression Builder", backend) {
        
        begin();
        int current_y = y + 40;
        
        new Fl_Box(x + 10, current_y, 100, 25, "Current Chord:");
        pc_selector = new PitchClassSelector(x + 120, current_y, w - 140, 25);
        
        current_y += 35;
        key_input = new Fl_Int_Input(x + 120, current_y, 60, 25, "Key (0-11):");
        key_input->value("0");
        
        edo_input = new Fl_Int_Input(x + 240, current_y, 60, 25, "EDO:");
        edo_input->value("12");
        
        current_y += 45;
        add_chord_btn = new Fl_Button(x + 10, current_y, 150, 30, "Add Chord to Prog.");
        add_chord_btn->callback(add_chord_cb, this);

        suggest_btn = new Fl_Button(x + 170, current_y, 150, 30, "Suggest Next Chord");
        suggest_btn->callback(suggest_cb, this);

        current_y += 35;
        analyze_prog_btn = new Fl_Button(x + 10, current_y, 150, 30, "Analyze Progression");
        analyze_prog_btn->callback(analyze_prog_cb, this);

        clear_prog_btn = new Fl_Button(x + 170, current_y, 150, 30, "Clear Progression");
        clear_prog_btn->callback(clear_prog_cb, this);

        current_y += 35;
        progression_buffer = new Fl_Text_Buffer();
        progression_display = new Fl_Text_Display(x + 10, current_y, w - 20, 100, "Progression");
        progression_display->buffer(progression_buffer);
        progression_display->textfont(FL_COURIER);
        progression_display->textsize(12);
        progression_display->box(FL_DOWN_BOX);

        end();
    }

private:
    PitchClassSelector* pc_selector;
    Fl_Int_Input* key_input;
    Fl_Int_Input* edo_input;
    Fl_Button* add_chord_btn;
    Fl_Button* suggest_btn;
    Fl_Button* analyze_prog_btn;
    Fl_Button* clear_prog_btn;
    Fl_Text_Buffer* progression_buffer;
    Fl_Text_Display* progression_display;

    std::vector<std::vector<int>> current_progression;

    void update_progression_display() {
        std::stringstream ss;
        ss << "Current Progression:\n";
        for (size_t i = 0; i < current_progression.size(); ++i) {
            ss << "[";
            for (size_t j = 0; j < current_progression[i].size(); ++j) {
                ss << current_progression[i][j] << (j == current_progression[i].size() - 1 ? "" : ", ");
            }
            ss << "]" << (i == current_progression.size() - 1 ? "" : " -> ");
        }
        progression_buffer->text(ss.str().c_str());
    }

    static void add_chord_cb(Fl_Widget*, void* data) {
        auto self = (ProgressionBuilderTab*)data;
        std::vector<int> pcs = self->pc_selector->get_selected_pcs();
        if (pcs.empty()) return;
        self->current_progression.push_back(pcs);
        self->update_progression_display();
    }

    static void suggest_cb(Fl_Widget*, void* data) {
        auto self = (ProgressionBuilderTab*)data;
        std::vector<int> pcs = self->pc_selector->get_selected_pcs();
        if (pcs.empty()) return;
        
        std::stringstream ss;
        ss << "{\"cmd\": \"suggest_completion\", \"pcs\": [";
        for (size_t i = 0; i < pcs.size(); ++i) {
            ss << pcs[i] << (i == pcs.size() - 1 ? "" : ", ");
        }
        ss << "], \"key\": " << self->key_input->value() << ", \"edo\": " << self->edo_input->value() << "}";
        
        std::string result = self->backend->send_command(ss.str());
        self->update_output(result);
    }

    static void analyze_prog_cb(Fl_Widget*, void* data) {
        auto self = (ProgressionBuilderTab*)data;
        if (self->current_progression.empty()) return;

        std::stringstream ss;
        ss << "{\"cmd\": \"detect_sequence\", \"chord_sequence\": [";
        for (size_t i = 0; i < self->current_progression.size(); ++i) {
            ss << "{\"root\": " << self->current_progression[i][0] << ", \"quality\": \"maj\"}"; // Simplified for now
            if (i < self->current_progression.size() - 1) ss << ", ";
        }
        ss << "]}";

        std::string result = self->backend->send_command(ss.str());
        self->update_output(result);
    }

    static void clear_prog_cb(Fl_Widget*, void* data) {
        auto self = (ProgressionBuilderTab*)data;
        self->current_progression.clear();
        self->update_progression_display();
        self->update_output("");
    }
};

/**
 * @brief Placeholder Tab for Automated Composition (Fractal Fluency).
 */
class AutomatedCompositionTab : public ModuleTab {
public:
    AutomatedCompositionTab(int x, int y, int w, int h, HarmoniaBackend* backend)
        : ModuleTab(x, y, w, h, "Automated Composition", backend) {
        
        begin();
        int current_y = y + 40;
        
        new Fl_Box(x + 10, current_y, w - 20, 50, "Fractal Fluency Search Engine (Coming Soon!)");
        
        // Placeholder for future controls and outputs
        
        end();
    }
};

#endif // UI_COMPONENTS_HPP
