# Formal Fractal Fluency Scoring and Search Model

This document synthesizes the academic research on psychoacoustic fractal fluency, information theory, and neurological foundations into a formal model for the Harmonia Theory Studio's automated composition engine. The goal is to create a scientifically grounded Fractal Fluency Score (FFS) and a search algorithm that leverages this score to generate musically fluent compositions.

## 1. Fractal Fluency Score (FFS) Definition

The Fractal Fluency Score (FFS) is a composite metric designed to quantify the perceptual fluency of a musical sequence. It is based on the principle that musical patterns exhibiting characteristics of 1/f noise and a specific fractal dimension are perceived as more natural, engaging, and aesthetically pleasing. The FFS will range from 0 to 1, where 1 represents optimal fractal fluency.

### 1.1. Components of FFS

The FFS will be calculated as a weighted sum of several sub-scores, each normalized between 0 and 1:

*   **Fractal Dimension Proximity (FDP)**: Measures how close the musical sequence's fractal dimension ($D_{actual}$) is to an optimal target fractal dimension ($D_{target} \approx 1.4$).
    $$FDP = 1 - \frac{|D_{actual} - D_{target}|}{D_{max} - D_{min}}$$ 
    Where $D_{max}$ and $D_{min}$ are the maximum and minimum possible fractal dimensions for the given musical parameter (e.g., pitch, rhythm).

*   **1/f Noise Conformity (ONC)**: Quantifies how well the power spectrum of the musical sequence's parameters (e.g., pitch intervals, rhythmic durations) conforms to a $1/f$ power law ($P(f) \propto 1/f^\beta$ with $\beta \approx 1$). This can be assessed by analyzing the slope of the power spectrum in a log-log plot.
    $$ONC = 1 - \frac{|\beta_{actual} - 1|}{max_{\beta} - min_{\beta}}$$ 
    Where $\beta_{actual}$ is the measured slope, and $max_{\beta}$, $min_{\beta}$ define the acceptable range for $1/f$ noise.

*   **Psychoacoustic Consonance (PC)**: Incorporates the existing psychoacoustic metrics from the Harmonia backend, such as Sethares roughness, tonal stability (Krumhansl-Kessler), and intermodulation consonance index (ICI). This component ensures local harmonic fluency.
    $$PC = w_1 \cdot Consonance + w_2 \cdot Stability + w_3 \cdot ICI$$ 
    Each sub-component ($Consonance$, $Stability$, $ICI$) is normalized to 0-1.

*   **Voice Leading Smoothness (VLS)**: Measures the smoothness of transitions between chords, minimizing large leaps and favoring step-wise motion. This contributes to perceptual ease.

### 1.2. Overall FFS Formula

The final FFS will be a weighted average:

$$FFS = w_{FDP} \cdot FDP + w_{ONC} \cdot ONC + w_{PC} \cdot PC + w_{VLS} \cdot VLS$$

The weights ($w_i$) will be configurable by the user in the UI, allowing for exploration of different fluency profiles.

## 2. Fractal Fluency Search Algorithm

The search algorithm will be a recursive, depth-first search (DFS) or breadth-first search (BFS) with pruning, guided by the FFS.

1.  **Initialization**: Start with a `seed_chord` and `key`. Define `search_depth` and `branching_factor`.
2.  **Recursive Step (`generate_next_chord(current_sequence, depth)`):**
    a.  **Generate Candidates**: Use the backend's `suggest_completion` (for voice leading) and `pivot_search` (for modulation) to generate a set of `candidate_chords` for the `current_sequence`.
    b.  **Calculate FFS for Candidates**: For each `candidate_chord`, calculate its contribution to the overall FFS of the `current_sequence + candidate_chord`. This involves:
        *   Analyzing the pitch and rhythmic patterns of the extended sequence to determine $D_{actual}$ and $\beta_{actual}$.
        *   Calling backend functions for psychoacoustic metrics (consonance, stability, ICI).
        *   Calculating voice leading smoothness from the `current_chord` to the `candidate_chord`.
    c.  **Pruning**: Select the top `branching_factor` candidates based on their FFS. This can be a local FFS or a projected cumulative FFS.
    d.  **Recursion**: For each selected candidate, recursively call `generate_next_chord(current_sequence + candidate_chord, depth + 1)` until `search_depth` is reached.
3.  **Path Selection**: After exploring all paths up to `search_depth`, select the path with the highest cumulative FFS.

## 3. Backend Integration Points

To support the FFS calculation, the Python backend will need new or enhanced functionalities:

*   **Fractal Dimension Calculation**: A new backend function to calculate the fractal dimension ($D$) of a given sequence of pitch intervals or rhythmic durations.
*   **1/f Noise Analysis**: A new backend function to perform power spectrum analysis on a sequence and return the $\beta$ value.
*   **Cumulative Psychoacoustic Analysis**: The existing psychoacoustic functions will need to be callable in a way that allows for efficient calculation over a sequence of chords.
*   **Voice Leading Cost**: The existing `orbifold_distance` or a similar metric can be used to quantify VLS.

## 4. UI Design for AutomatedCompositionTab (Refined)

### 4.1. Search Parameters
*   **Seed Chord**: `PitchClassSelector`.
*   **Key & EDO**: `Fl_Int_Input`.
*   **Search Depth**: `Fl_Int_Input`.
*   **Branching Factor**: `Fl_Int_Input`.
*   **FFS Weight Sliders**: `Fl_Value_Slider` for $w_{FDP}$, $w_{ONC}$, $w_{PC}$, $w_{VLS}$.

### 4.2. Controls & Progress
*   **Generate Composition Button**: Triggers the search.
*   **Stop Button**: To interrupt the search.
*   **Progress Bar**: `Fl_Progress`.

### 4.3. Results & Visualization
*   **Composition Display**: `Fl_Text_Display` to show the generated chord sequence, potentially with FFS for each chord.
*   **Graphical Representation (Future)**: A visual tree of the search space or a plot of the FFS over time.

## 5. References

[1] Taylor, R. P., & Spehar, B. (2016). Fractal fluency: An intimate relationship between the brain and processing of fractal stimuli. In *The fractal geometry of the brain* (pp. 907-934). Springer.
[2] Hsu, K. J., & Hsu, A. (1991). Self-similarity of the "1/f noise" called music. *Proceedings of the National Academy of Sciences*, *88*(8), 3507-3509.
[3] Levitin, D. J., & Menon, V. (2003). Musical rhythm spectra from Bach to Joplin obey a 1/f power law. *Proceedings of the National Academy of Sciences*, *100*(6), 3516-3520.
[4] Reber, A. S., & Schwarz, N. (1999). Effects of perceptual fluency on affective judgments. *European Journal of Social Psychology*, *29*(2-3), 237-245.
[5] Taylor, R. P. (2006). Fractal patterns in nature and art are aesthetically pleasing and stress-reducing. *Interalia Magazine*.
