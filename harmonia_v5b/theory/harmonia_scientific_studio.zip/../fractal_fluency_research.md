# Research Findings: Psychoacoustic Fractal Fluency

## 1. Core Definitions
*   **Fractal Fluency**: The human auditory (and visual) system is "hardwired" to process fractal patterns with mid-range complexity (Fractal Dimension $D \approx 1.3 - 1.5$) with high efficiency and low metabolic cost.
*   **1/f Noise (Pink Noise)**: Music that follows a $1/f^\beta$ power spectrum (where $\beta \approx 1$) is perceived as more "natural" and "fluent." This applies to both pitch (frequency) and duration (rhythm).
*   **Scale Invariance**: Fractal music exhibits self-similarity across different time scales.

## 2. Mathematical Foundations
*   **Fractal Dimension ($D$)**: In music, $D$ can be calculated from the relationship between the "yardstick" length $\epsilon$ (e.g., number of notes) and the total "length" $L(\epsilon)$ of the melody (sum of intervals).
*   **Richardson Effect**: $L(\epsilon) \propto \epsilon^{1-D}$.
*   **Power Law**: The frequency of occurrence of intervals $i$ follows $F(i) \propto 1/i^D$.
*   **Zipf's Law in Music**: The distribution of pitches and intervals often follows a Zipfian distribution, which is a discrete form of the power law.

## 3. Neurological Foundations
*   **Processing Fluency Theory**: Aesthetic pleasure is derived from the ease of processing a stimulus. Fractal patterns with $D \approx 1.4$ are processed by the auditory cortex with optimal resonance.
*   **Neural Oscillations**: The brain's endogenous oscillations (alpha, beta, gamma) exhibit $1/f$ scaling. Musical stimuli that match this scaling can "entrain" neural activity more effectively.
*   **Dopaminergic Reward**: Fluent processing of complex but predictable patterns (like fractals) triggers the release of dopamine in the striatum.

## 4. Information Theory Foundations
*   **Kolmogorov Complexity**: Fractal fluency sits at the sweet spot between low complexity (monotony) and high complexity (randomness).
*   **Entropy Rate**: The rate at which new information is introduced in a fractal sequence is constant across scales, allowing for continuous engagement without overwhelming the listener.
*   **Surprisal vs. Predictability**: 1/f noise provides a balance where each note is somewhat predictable from the past but still contains "surprisal."

## 5. Implementation Strategy for the Search Engine
*   **Scoring Function**: Replace the heuristic weights with a "Fluency Index" ($FI$) calculated as:
    $FI = 1 - |D_{actual} - D_{target}|$, where $D_{target} \approx 1.4$.
*   **Power Spectrum Analysis**: Use FFT on the generated sequence to check for $1/f$ slope.
*   **Information Rate Control**: Ensure the entropy rate of the generated sequence remains within the "fluent" range.
