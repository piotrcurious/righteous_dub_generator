#ifndef BACKEND_INTERFACE_HPP
#define BACKEND_INTERFACE_HPP

#include <string>
#include <iostream>
#include <cstdio>
#include <memory>
#include <stdexcept>
#include <array>
#include <vector>
#include <sstream>

/**
 * @brief Simple interface to communicate with the Python Harmonia Theory Server.
 * 
 * This class handles spawning the Python process and communicating via JSON over pipes.
 */
class HarmoniaBackend {
public:
    HarmoniaBackend(const std::string& python_script_path) 
        : script_path(python_script_path) {
    }

    std::string send_command(const std::string& json_cmd) {
        // We'll use a simple approach: call the script with the JSON as input
        // and capture the output.
        // For safety, we should escape the JSON string for the shell.
        // This is a basic implementation for the demo.
        std::string command = "echo '" + json_cmd + "' | python3 " + script_path;
        
        std::array<char, 4096> buffer;
        std::string result;
        std::unique_ptr<FILE, decltype(&pclose)> pipe(popen(command.c_str(), "r"), pclose);
        
        if (!pipe) {
            return "{\"result\": \"error\", \"message\": \"Failed to start backend\"}";
        }
        
        while (fgets(buffer.data(), buffer.size(), pipe.get()) != nullptr) {
            result += buffer.data();
        }
        
        return result;
    }

private:
    std::string script_path;
};

#endif // BACKEND_INTERFACE_HPP
