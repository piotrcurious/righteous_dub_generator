#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Tabs.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Menu_Bar.H>
#include <FL/fl_ask.H>

#include "backend_interface.hpp"
#include "ui_components.hpp"

int main(int argc, char **argv) {
    // Path to the Python script
    // Note: In a real deployment, this would be a local path.
    const char* python_script = "/home/ubuntu/upload/pasted_content.txt";
    HarmoniaBackend backend(python_script);

    // Main window setup
    Fl_Window *win = new Fl_Window(1000, 700, "Harmonia Theory Studio - Fractal Fluency Edition");
    win->color(FL_LIGHT3);

    // Menu Bar
    Fl_Menu_Bar *menu = new Fl_Menu_Bar(0, 0, 1000, 30);
    menu->add("File/Quit", FL_CTRL + 'q', [](Fl_Widget*, void*) { exit(0); });
    menu->add("Help/About", 0, [](Fl_Widget*, void*) { 
        fl_message("Harmonia Theory Studio\nFLTK Frontend v2.0\nFractal Fluency Edition"); 
    });

    // Tabbed Interface
    Fl_Tabs *tabs = new Fl_Tabs(10, 40, 980, 650);
    
    // Tab 1: Psychoacoustics
    PsychoacousticTab *tab1 = new PsychoacousticTab(10, 70, 980, 620, &backend);
    
    // Tab 2: Functional Theory
    FunctionalTab *tab2 = new FunctionalTab(10, 70, 980, 620, &backend);
    
    // Tab 3: Modulation
    ModulationTab *tab3 = new ModulationTab(10, 70, 980, 620, &backend);

    // Tab 4: Arpeggio & Scales
    ArpeggioTab *tab4 = new ArpeggioTab(10, 70, 980, 620, &backend);

    // Tab 5: Progression Builder
    ProgressionBuilderTab *tab5 = new ProgressionBuilderTab(10, 70, 980, 620, &backend);

    // Tab 6: Automated Composition (Fractal Fluency)
    AutomatedCompositionTab *tab6 = new AutomatedCompositionTab(10, 70, 980, 620, &backend);
    
    tabs->end();

    win->end();
    win->resizable(tabs);
    win->show(argc, argv);

    return Fl::run();
}
