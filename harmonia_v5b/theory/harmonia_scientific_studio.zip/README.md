# Harmonia Theory Server - FLTK Frontend

This is a C++ frontend for the Harmonia Theory Server, built using the FLTK (Fast Light Toolkit) library. It provides a graphical interface to interact with the psychoacoustic and music theory engine.

## Features

*   **Psychoacoustic Analysis**: Explore Sethares roughness, IHC compression, and intermodulation consonance.
*   **Functional Theory**: Analyze chords for their set-class properties, functional roles, and Tonnetz tension.
*   **Modulation Search**: Find pivot chords and modulation paths between different keys.
*   **Multi-EDO Support**: All analyses support customizable Equal Divisions of the Octave.

## Prerequisites

*   **C++ Compiler**: `g++` or `clang++`.
*   **FLTK Library**: Version 1.3 or higher.
*   **Python 3**: To run the backend logic.

## Build Instructions

### Linux (Ubuntu/Debian)

1.  Install dependencies:
    ```bash
    sudo apt-get update
    sudo apt-get install -y libfltk1.3-dev
    ```

2.  Compile the application:
    ```bash
    g++ -o harmonia_ui main.cpp `fltk-config --cxxflags --ldflags`
    ```

### macOS

1.  Install FLTK via Homebrew:
    ```bash
    brew install fltk
    ```

2.  Compile:
    ```bash
    g++ -o harmonia_ui main.cpp `fltk-config --cxxflags --ldflags`
    ```

## Running the Application

Ensure the Python backend script is in the correct location (as specified in `main.cpp`) and then run:

```bash
./harmonia_ui
```

## Architecture

The frontend acts as a thin UI layer that communicates with the Python backend via JSON over standard input/output. This ensures that the complex music theory logic remains decoupled from the interface.
