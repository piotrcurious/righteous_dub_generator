#ifndef UI_COMPONENTS_HPP
#define UI_COMPONENTS_HPP

#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Tabs.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Input.H>
#include <FL/Fl_Int_Input.H>
#include <FL/Fl_Float_Input.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Text_Display.H>
#include <FL/Fl_Text_Buffer.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Choice.H>
#include <FL/Fl_Check_Button.H>
#include <FL/Fl_Value_Slider.H>
#include <FL/Fl_Progress.H>

#include "backend_interface.hpp"
#include <vector>
#include <string>
#include <sstream>
#include <iomanip> // For std::fixed and std::setprecision
#include <algorithm>
#include <thread>
#include <atomic>
#include <mutex>
#include <jsoncpp/json/json.h> // Assuming a JSON library is available for parsing backend responses

// Forward declaration
class HarmoniaBackend;

/**
 * @brief A basic pitch-class selector widget using buttons.
 */
class PitchClassSelector : public Fl_Group {
public:
    PitchClassSelector(int x, int y, int w, int h, const char* l = 0)
        : Fl_Group(x, y, w, h, l) {
        
        int btn_w = w / 12;
        const char* labels[] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
        
        begin();
        for (int i = 0; i < 12; ++i) {
            buttons[i] = new Fl_Check_Button(x + i * btn_w, y, btn_w, h, labels[i]);
            buttons[i]->type(FL_TOGGLE_BUTTON);
        }
        end();
    }

    std::vector<int> get_selected_pcs() const {
        std::vector<int> pcs;
        for (int i = 0; i < 12; ++i) {
            if (buttons[i]->value()) {
                pcs.push_back(i);
            }
        }
        return pcs;
    }

    void set_selected_pcs(const std::vector<int>& pcs) {
        for (int i = 0; i < 12; ++i) {
            buttons[i]->value(0); // Clear all first
        }
        for (int pc : pcs) {
            if (pc >= 0 && pc < 12) {
                buttons[pc]->value(1);
            }
        }
    }

private:
    Fl_Check_Button* buttons[12];
};

/**
 * @brief Base class for each tab/module in the UI.
 */
class ModuleTab : public Fl_Group {
public:
    ModuleTab(int x, int y, int w, int h, const char* l, HarmoniaBackend* backend)
        : Fl_Group(x, y, w, h, l), backend(backend) {
        
        begin();
        output_buffer = new Fl_Text_Buffer();
        output_display = new Fl_Text_Display(x + 10, y + h - 210, w - 20, 200, "Analysis Result");
        output_display->buffer(output_buffer);
        output_display->textfont(FL_COURIER);
        output_display->textsize(12);
        output_display->box(FL_DOWN_BOX);
        end();
    }

protected:
    HarmoniaBackend* backend;
    Fl_Text_Buffer* output_buffer;
    Fl_Text_Display* output_display;

    void update_output(const std::string& text) {
        output_buffer->text(text.c_str());
    }
};

/**
 * @brief Tab for Psychoacoustic Analysis.
 */
class PsychoacousticTab : public ModuleTab {
public:
    PsychoacousticTab(int x, int y, int w, int h, HarmoniaBackend* backend)
        : ModuleTab(x, y, w, h, "Psychoacoustics", backend) {
        
        begin();
        int current_y = y + 40;
        
        new Fl_Box(x + 10, current_y, 100, 25, "Pitch Classes:");
        pc_selector = new PitchClassSelector(x + 120, current_y, w - 140, 25);
        
        current_y += 35;
        edo_input = new Fl_Int_Input(x + 120, current_y, 60, 25, "EDO:");
        edo_input->value("12");
        
        octave_input = new Fl_Int_Input(x + 240, current_y, 60, 25, "Octave:");
        octave_input->value("4");
        
        current_y += 45;
        analyze_btn = new Fl_Button(x + 10, current_y, 180, 30, "Analyze Psychoacoustics");
        analyze_btn->callback(analyze_cb, this);
        
        im_analyze_btn = new Fl_Button(x + 200, current_y, 200, 30, "Intermodulation Analysis");
        im_analyze_btn->callback(im_analyze_cb, this);
        
        end();
    }

private:
    PitchClassSelector* pc_selector;
    Fl_Int_Input* edo_input;
    Fl_Int_Input* octave_input;
    Fl_Button* analyze_btn;
    Fl_Button* im_analyze_btn;

    static void analyze_cb(Fl_Widget*, void* data) {
        auto self = (PsychoacousticTab*)data;
        std::vector<int> pcs = self->pc_selector->get_selected_pcs();
        if (pcs.empty()) return;
        
        std::stringstream ss;
        ss << "{\"cmd\": \"psychoacoustic_analysis\", \"pcs\": [";
        for (size_t i = 0; i < pcs.size(); ++i) {
            ss << pcs[i] << (i == pcs.size() - 1 ? "" : ", ");
        }
        ss << "], \"edo\": " << self->edo_input->value() << ", \"octave\": " << self->octave_input->value() << "}";
        
        std::string result = self->backend->send_command(ss.str());
        self->update_output(result);
    }

    static void im_analyze_cb(Fl_Widget*, void* data) {
        auto self = (PsychoacousticTab*)data;
        std::vector<int> pcs = self->pc_selector->get_selected_pcs();
        if (pcs.empty()) return;
        
        std::stringstream ss;
        ss << "{\"cmd\": \"intermodulation_analysis\", \"pcs\": [";
        for (size_t i = 0; i < pcs.size(); ++i) {
            ss << pcs[i] << (i == pcs.size() - 1 ? "" : ", ");
        }
        ss << "], \"edo\": " << self->edo_input->value() << ", \"octave\": " << self->octave_input->value() << "}";
        
        std::string result = self->backend->send_command(ss.str());
        self->update_output(result);
    }
};

/**
 * @brief Tab for Functional Analysis.
 */
class FunctionalTab : public ModuleTab {
public:
    FunctionalTab(int x, int y, int w, int h, HarmoniaBackend* backend)
        : ModuleTab(x, y, w, h, "Functional Theory", backend) {
        
        begin();
        int current_y = y + 40;
        
        new Fl_Box(x + 10, current_y, 100, 25, "Chord PCs:");
        pc_selector = new PitchClassSelector(x + 120, current_y, w - 140, 25);
        
        current_y += 35;
        key_input = new Fl_Int_Input(x + 120, current_y, 60, 25, "Key (0-11):");
        key_input->value("0");
        
        edo_input = new Fl_Int_Input(x + 240, current_y, 60, 25, "EDO:");
        edo_input->value("12");
        
        current_y += 45;
        analyze_btn = new Fl_Button(x + 10, current_y, 150, 30, "Analyze Chord");
        analyze_btn->callback(analyze_cb, this);
        
        end();
    }

private:
    PitchClassSelector* pc_selector;
    Fl_Int_Input* key_input;
    Fl_Int_Input* edo_input;
    Fl_Button* analyze_btn;

    static void analyze_cb(Fl_Widget*, void* data) {
        auto self = (FunctionalTab*)data;
        std::vector<int> pcs = self->pc_selector->get_selected_pcs();
        if (pcs.empty()) return;
        
        std::stringstream ss;
        ss << "{\"cmd\": \"analyze_chord\", \"pcs\": [";
        for (size_t i = 0; i < pcs.size(); ++i) {
            ss << pcs[i] << (i == pcs.size() - 1 ? "" : ", ");
        }
        ss << "], \"key\": " << self->key_input->value() << ", \"edo\": " << self->edo_input->value() << "}";
        
        std::string result = self->backend->send_command(ss.str());
        self->update_output(result);
    }
};

/**
 * @brief Tab for Modulation & Pivot Search.
 */
class ModulationTab : public ModuleTab {
public:
    ModulationTab(int x, int y, int w, int h, HarmoniaBackend* backend)
        : ModuleTab(x, y, w, h, "Modulation", backend) {
        
        begin();
        int current_y = y + 40;
        
        key_from_input = new Fl_Int_Input(x + 120, current_y, 60, 25, "Key From:");
        key_from_input->value("0");
        
        key_to_input = new Fl_Int_Input(x + 240, current_y, 60, 25, "Key To:");
        key_to_input->value("7");
        
        current_y += 35;
        edo_input = new Fl_Int_Input(x + 120, current_y, 60, 25, "EDO:");
        edo_input->value("12");
        
        current_y += 45;
        search_btn = new Fl_Button(x + 10, current_y, 150, 30, "Search Pivots");
        search_btn->callback(search_cb, this);
        
        end();
    }

private:
    Fl_Int_Input* key_from_input;
    Fl_Int_Input* key_to_input;
    Fl_Int_Input* edo_input;
    Fl_Button* search_btn;

    static void search_cb(Fl_Widget*, void* data) {
        auto self = (ModulationTab*)data;
        std::stringstream ss;
        ss << "{\"cmd\": \"pivot_search\", \"key_from\": " << self->key_from_input->value() 
           << ", \"key_to\": " << self->key_to_input->value() << ", \"edo\": " << self->edo_input->value() << "}";
        
        std::string result = self->backend->send_command(ss.str());
        self->update_output(result);
    }
};

/**
 * @brief Tab for Arpeggio & Scale Exploration.
 */
class ArpeggioTab : public ModuleTab {
public:
    ArpeggioTab(int x, int y, int w, int h, HarmoniaBackend* backend)
        : ModuleTab(x, y, w, h, "Arpeggios & Scales", backend) {
        
        begin();
        int current_y = y + 40;
        
        root_input = new Fl_Int_Input(x + 120, current_y, 60, 25, "Root (0-11):");
        root_input->value("0");
        
        edo_input = new Fl_Int_Input(x + 240, current_y, 60, 25, "EDO:");
        edo_input->value("12");
        
        current_y += 35;
        type_choice = new Fl_Choice(x + 120, current_y, 150, 25, "Type:");
        type_choice->add("Major");
        type_choice->add("Minor");
        type_choice->add("Dominant 7th");
        type_choice->add("Diminished 7th");
        type_choice->add("Major Pentatonic");
        type_choice->add("Minor Pentatonic");
        type_choice->value(0);
        
        current_y += 45;
        generate_btn = new Fl_Button(x + 10, current_y, 180, 30, "Generate Arpeggio/Scale");
        generate_btn->callback(generate_cb, this);
        
        end();
    }

private:
    Fl_Int_Input* root_input;
    Fl_Int_Input* edo_input;
    Fl_Choice* type_choice;
    Fl_Button* generate_btn;

    static void generate_cb(Fl_Widget*, void* data) {
        auto self = (ArpeggioTab*)data;
        int root_pc = std::stoi(self->root_input->value());
        int edo = std::stoi(self->edo_input->value());

        std::vector<int> generated_pcs;
        std::string type = self->type_choice->text();

        if (type == "Major") generated_pcs = {0, 4, 7};
        else if (type == "Minor") generated_pcs = {0, 3, 7};
        else if (type == "Dominant 7th") generated_pcs = {0, 4, 7, 10};
        else if (type == "Diminished 7th") generated_pcs = {0, 3, 6, 9};
        else if (type == "Major Pentatonic") generated_pcs = {0, 2, 4, 7, 9};
        else if (type == "Minor Pentatonic") generated_pcs = {0, 3, 5, 7, 10};
        
        std::stringstream output_ss;
        output_ss << "Generated " << type << " (Root: " << root_pc << ", EDO: " << edo << "):\n";
        output_ss << "Pitch Classes: ";
        for (size_t i = 0; i < generated_pcs.size(); ++i) {
            output_ss << (root_pc + generated_pcs[i]) % edo << (i == generated_pcs.size() - 1 ? "" : ", ");
        }
        output_ss << "\n";
        self->update_output(output_ss.str());
    }
};

/**
 * @brief Tab for Progression Builder.
 */
class ProgressionBuilderTab : public ModuleTab {
public:
    ProgressionBuilderTab(int x, int y, int w, int h, HarmoniaBackend* backend)
        : ModuleTab(x, y, w, h, "Progression Builder", backend) {
        
        begin();
        int current_y = y + 40;
        
        new Fl_Box(x + 10, current_y, 100, 25, "Current Chord:");
        pc_selector = new PitchClassSelector(x + 120, current_y, w - 140, 25);
        
        current_y += 35;
        key_input = new Fl_Int_Input(x + 120, current_y, 60, 25, "Key (0-11):");
        key_input->value("0");
        
        edo_input = new Fl_Int_Input(x + 240, current_y, 60, 25, "EDO:");
        edo_input->value("12");
        
        current_y += 45;
        add_chord_btn = new Fl_Button(x + 10, current_y, 150, 30, "Add Chord to Prog.");
        add_chord_btn->callback(add_chord_cb, this);

        suggest_btn = new Fl_Button(x + 170, current_y, 150, 30, "Suggest Next Chord");
        suggest_btn->callback(suggest_cb, this);

        current_y += 35;
        analyze_prog_btn = new Fl_Button(x + 10, current_y, 150, 30, "Analyze Progression");
        analyze_prog_btn->callback(analyze_prog_cb, this);

        clear_prog_btn = new Fl_Button(x + 170, current_y, 150, 30, "Clear Progression");
        clear_prog_btn->callback(clear_prog_cb, this);

        current_y += 35;
        progression_buffer = new Fl_Text_Buffer();
        progression_display = new Fl_Text_Display(x + 10, current_y, w - 20, 100, "Progression");
        progression_display->buffer(progression_buffer);
        progression_display->textfont(FL_COURIER);
        progression_display->textsize(12);
        progression_display->box(FL_DOWN_BOX);

        end();
    }

private:
    PitchClassSelector* pc_selector;
    Fl_Int_Input* key_input;
    Fl_Int_Input* edo_input;
    Fl_Button* add_chord_btn;
    Fl_Button* suggest_btn;
    Fl_Button* analyze_prog_btn;
    Fl_Button* clear_prog_btn;
    Fl_Text_Buffer* progression_buffer;
    Fl_Text_Display* progression_display;

    std::vector<std::vector<int>> current_progression;

    void update_progression_display() {
        std::stringstream ss;
        ss << "Current Progression:\n";
        for (size_t i = 0; i < current_progression.size(); ++i) {
            ss << "[\"";
            for (size_t j = 0; j < current_progression[i].size(); ++j) {
                ss << current_progression[i][j] << (j == current_progression[i].size() - 1 ? "" : ", ");
            }
            ss << "]" << (i == current_progression.size() - 1 ? "" : " -> ");
        }
        progression_buffer->text(ss.str().c_str());
    }

    static void add_chord_cb(Fl_Widget*, void* data) {
        auto self = (ProgressionBuilderTab*)data;
        std::vector<int> pcs = self->pc_selector->get_selected_pcs();
        if (pcs.empty()) return;
        self->current_progression.push_back(pcs);
        self->update_progression_display();
    }

    static void suggest_cb(Fl_Widget*, void* data) {
        auto self = (ProgressionBuilderTab*)data;
        std::vector<int> pcs = self->pc_selector->get_selected_pcs();
        if (pcs.empty()) return;
        
        std::stringstream ss;
        ss << "{\"cmd\": \"suggest_completion\", \"pcs\": [";
        for (size_t i = 0; i < pcs.size(); ++i) {
            ss << pcs[i] << (i == pcs.size() - 1 ? "" : ", ");
        }
        ss << "], \"key\": " << self->key_input->value() << ", \"edo\": " << self->edo_input->value() << "}";
        
        std::string result = self->backend->send_command(ss.str());
        self->update_output(result);
    }

    static void analyze_prog_cb(Fl_Widget*, void* data) {
        auto self = (ProgressionBuilderTab*)data;
        if (self->current_progression.empty()) return;

        std::stringstream ss;
        ss << "{\"cmd\": \"detect_sequence\", \"chord_sequence\": [";
        for (size_t i = 0; i < self->current_progression.size(); ++i) {
            ss << "{\"root\": " << self->current_progression[i][0] << ", \"quality\": \"maj\"}";
            if (i < self->current_progression.size() - 1) ss << ", ";
        }
        ss << "]}";

        std::string result = self->backend->send_command(ss.str());
        self->update_output(result);
    }

    static void clear_prog_cb(Fl_Widget*, void* data) {
        auto self = (ProgressionBuilderTab*)data;
        self->current_progression.clear();
        self->update_progression_display();
        self->update_output("");
    }
};

// Structure to hold a chord in the composition tree
struct CompositionChord {
    std::vector<int> pcs;
    double ffs_score; // Fractal Fluency Score for this chord in the sequence
    std::string name; // Human-readable name
};

// Structure to hold a path in the composition tree
struct CompositionPath {
    std::vector<CompositionChord> chords;
    double cumulative_ffs = 0.0;
};

/**
 * @brief Tab for Automated Composition (Fractal Fluency Search Engine).
 */
class AutomatedCompositionTab : public ModuleTab {
public:
    AutomatedCompositionTab(int x, int y, int w, int h, HarmoniaBackend* backend)
        : ModuleTab(x, y, w, h, "Fractal Fluency", backend), search_running(false) {
        
        begin();
        int current_y = y + 40;
        
        // Left Panel: Search Parameters
        Fl_Group* param_group = new Fl_Group(x + 10, current_y, w / 3 - 15, h - 250, "Parameters");
        param_group->box(FL_ENGRAVED_FRAME);
        param_group->begin();
        
        int param_y = current_y + 20;
        new Fl_Box(x + 20, param_y, 100, 25, "Seed Chord:");
        pc_selector = new PitchClassSelector(x + 130, param_y, param_group->w() - 140, 25);
        
        param_y += 35;
        key_input = new Fl_Int_Input(x + 130, param_y, 60, 25, "Key:");
        key_input->value("0");

        edo_input = new Fl_Int_Input(x + 250, param_y, 60, 25, "EDO:");
        edo_input->value("12");
        
        param_y += 35;
        depth_input = new Fl_Int_Input(x + 130, param_y, 60, 25, "Depth:");
        depth_input->value("4");
        
        branch_input = new Fl_Int_Input(x + 250, param_y, 60, 25, "Branching:");
        branch_input->value("3");
        
        param_y += 45;
        new Fl_Box(x + 20, param_y, 100, 25, "FFS Weights:");
        
        param_y += 25;
        fdp_slider = new Fl_Value_Slider(x + 130, param_y, param_group->w() - 140, 20, "FDP");
        fdp_slider->type(FL_HOR_SLIDER);
        fdp_slider->range(0.0, 1.0);
        fdp_slider->value(0.25);
        fdp_slider->step(0.01);
        
        param_y += 25;
        onc_slider = new Fl_Value_Slider(x + 130, param_y, param_group->w() - 140, 20, "1/f Noise");
        onc_slider->type(FL_HOR_SLIDER);
        onc_slider->range(0.0, 1.0);
        onc_slider->value(0.25);
        onc_slider->step(0.01);

        param_y += 25;
        pc_slider = new Fl_Value_Slider(x + 130, param_y, param_group->w() - 140, 20, "Psychoac.");
        pc_slider->type(FL_HOR_SLIDER);
        pc_slider->range(0.0, 1.0);
        pc_slider->value(0.25);
        pc_slider->step(0.01);

        param_y += 25;
        vls_slider = new Fl_Value_Slider(x + 130, param_y, param_group->w() - 140, 20, "Voice Lead.");
        vls_slider->type(FL_HOR_SLIDER);
        vls_slider->range(0.0, 1.0);
        vls_slider->value(0.25);
        vls_slider->step(0.01);

        param_group->end();

        // Center Panel: Controls & Progress
        Fl_Group* control_group = new Fl_Group(x + w / 3, current_y, w / 3 - 15, h - 250, "Controls");
        control_group->box(FL_ENGRAVED_FRAME);
        control_group->begin();

        int control_y = current_y + 20;
        generate_btn = new Fl_Button(x + w / 3 + 10, control_y, control_group->w() - 20, 30, "Generate Composition");
        generate_btn->callback(generate_cb, this);
        
        control_y += 40;
        stop_btn = new Fl_Button(x + w / 3 + 10, control_y, control_group->w() - 20, 30, "Stop Search");
        stop_btn->callback(stop_cb, this);
        stop_btn->deactivate();

        control_y += 40;
        progress_bar = new Fl_Progress(x + w / 3 + 10, control_y, control_group->w() - 20, 30);
        progress_bar->minimum(0);
        progress_bar->maximum(100);
        progress_bar->value(0);
        
        control_group->end();

        // Right Panel: Results & Visualization
        Fl_Group* result_group = new Fl_Group(x + 2 * w / 3, current_y, w / 3 - 10, h - 250, "Results");
        result_group->box(FL_ENGRAVED_FRAME);
        result_group->begin();

        int result_y = current_y + 20;
        composition_buffer = new Fl_Text_Buffer();
        composition_display = new Fl_Text_Display(x + 2 * w / 3 + 10, result_y, result_group->w() - 20, h - 280, "Best Composition Path");
        composition_display->buffer(composition_buffer);
        composition_display->textfont(FL_COURIER);
        composition_display->textsize(12);
        composition_display->box(FL_DOWN_BOX);

        result_group->end();

        end();
    }

private:
    PitchClassSelector* pc_selector;
    Fl_Int_Input* key_input;
    Fl_Int_Input* edo_input;
    Fl_Int_Input* depth_input;
    Fl_Int_Input* branch_input;
    Fl_Value_Slider* fdp_slider;
    Fl_Value_Slider* onc_slider;
    Fl_Value_Slider* pc_slider;
    Fl_Value_Slider* vls_slider;
    Fl_Button* generate_btn;
    Fl_Button* stop_btn;
    Fl_Progress* progress_bar;
    Fl_Text_Buffer* composition_buffer;
    Fl_Text_Display* composition_display;
    
    std::atomic<bool> search_running;
    std::atomic<bool> stop_requested;
    std::mutex mtx; // For protecting shared resources if needed

    // Helper to parse JSON string to get a specific value
    std::string get_json_value(const std::string& json_str, const std::string& key) {
        Json::Value root;
        Json::Reader reader;
        if (reader.parse(json_str, root)) {
            return root.get(key, "").asString();
        }
        return "";
    }

    // Actual FFS calculation using backend calls
    double calculate_ffs(const std::vector<std::vector<int>>& sequence, int key, int edo) {
        if (sequence.size() < 2) return 0.5; // Neutral score for short sequences

        std::stringstream ss;
        ss << "{\"cmd\": \"fractal_fluency_analysis\", \"sequence\": [";
        for (size_t i = 0; i < sequence.size(); ++i) {
            ss << "[";
            for (size_t j = 0; j < sequence[i].size(); ++j) {
                ss << sequence[i][j] << (j == sequence[i].size() - 1 ? "" : ", ");
            }
            ss << "]" << (i == sequence.size() - 1 ? "" : ", ");
        }
        ss << "], \"key\": " << key << ", \"edo\": " << edo << "}";
        
        std::string result_str = backend->send_command(ss.str());
        Json::Value result_json;
        Json::Reader reader;
        if (!reader.parse(result_str, result_json)) return 0.5;

        double fdp_score = result_json.get("fdp_score", 0.5).asDouble();
        double onc_score = result_json.get("onc_score", 0.5).asDouble();
        
        // Local psychoacoustic and voice leading components (simplified integration)
        double pc_weight = pc_slider->value();
        double vls_weight = vls_slider->value();
        double fdp_weight = fdp_slider->value();
        double onc_weight = onc_slider->value();
        
        double total_weight = fdp_weight + onc_weight + pc_weight + vls_weight;
        if (total_weight <= 0) return 0.5;

        // Final weighted FFS
        return (fdp_weight * fdp_score + onc_weight * onc_score + pc_weight * 0.7 + vls_weight * 0.8) / total_weight;
    }

    // Recursive function for fractal search
    CompositionPath fractal_search_recursive(
        std::vector<std::vector<int>> current_sequence,
        int current_depth,
        int max_depth,
        int branching_factor,
        int key,
        int edo,
        std::atomic<bool>& stop_flag
    ) {
        if (stop_flag) return {};

        if (current_depth == max_depth) {
            CompositionPath path;
            for (const auto& pcs : current_sequence) {
                // Simulate chord name for display
                std::stringstream ss;
                ss << "[";
                for(size_t i=0; i<pcs.size(); ++i) ss << pcs[i] << (i==pcs.size()-1?"":" ");
                ss << "]";
                path.chords.push_back({pcs, 0.0, ss.str()}); // FFS will be calculated later
            }
            path.cumulative_ffs = calculate_ffs(current_sequence, key, edo); // Calculate final FFS for the path
            return path;
        }

        // Generate candidates for the next chord
        std::vector<int> last_chord_pcs = current_sequence.empty() ? std::vector<int>() : current_sequence.back();
        
        std::stringstream ss_suggest;
        ss_suggest << "{\"cmd\": \"suggest_completion\", \"pcs\": [";
        for (size_t i = 0; i < last_chord_pcs.size(); ++i) {
            ss_suggest << last_chord_pcs[i] << (i == last_chord_pcs.size() - 1 ? "" : ", ");
        }
        ss_suggest << "], \"key\": " << key << ", \"edo\": " << edo << "}";
        
        std::string suggest_result_str = backend->send_command(ss_suggest.str());
        
        Json::Value suggest_result_json;
        Json::Reader reader;
        reader.parse(suggest_result_str, suggest_result_json);

        std::vector<std::pair<double, std::vector<int>>> scored_candidates;
        if (suggest_result_json.isMember("suggestions") && suggest_result_json["suggestions"].isArray()) {
            for (const auto& suggestion : suggest_result_json["suggestions"]) {
                if (suggestion.isMember("pc") && suggestion.isMember("score")) {
                    std::vector<int> candidate_pcs = last_chord_pcs;
                    candidate_pcs.push_back(suggestion["pc"].asInt());
                    std::sort(candidate_pcs.begin(), candidate_pcs.end());
                    
                    // Calculate FFS for this candidate
                    std::vector<std::vector<int>> test_sequence = current_sequence;
                    test_sequence.push_back(candidate_pcs);
                    double candidate_ffs = calculate_ffs(test_sequence, key, edo);
                    scored_candidates.push_back({candidate_ffs, candidate_pcs});
                }
            }
        }

        // Sort candidates by FFS (descending) and select top 'branching_factor'
        std::sort(scored_candidates.rbegin(), scored_candidates.rend());
        if (scored_candidates.size() > branching_factor) {
            scored_candidates.resize(branching_factor);
        }

        CompositionPath best_path_so_far;
        best_path_so_far.cumulative_ffs = -1.0; // Initialize with a very low score

        for (const auto& candidate : scored_candidates) {
            if (stop_flag) return {};

            std::vector<std::vector<int>> next_sequence = current_sequence;
            next_sequence.push_back(candidate.second);
            
            CompositionPath sub_path = fractal_search_recursive(
                next_sequence, current_depth + 1, max_depth, branching_factor, key, edo, stop_flag
            );

            if (stop_flag) return {};

            if (sub_path.cumulative_ffs > best_path_so_far.cumulative_ffs) {
                best_path_so_far = sub_path;
            }
        }
        return best_path_so_far;
    }

    static void generate_cb(Fl_Widget*, void* data) {
        auto self = (AutomatedCompositionTab*)data;
        if (self->search_running) return;
        
        self->search_running = true;
        self->stop_requested = false;
        self->generate_btn->deactivate();
        self->stop_btn->activate();
        self->progress_bar->value(0);
        self->composition_buffer->text("Searching for fluent composition...");
        
        std::thread([self]() {
            int depth = std::stoi(self->depth_input->value());
            int branching_factor = std::stoi(self->branch_input->value());
            int key = std::stoi(self->key_input->value());
            int edo = std::stoi(self->edo_input->value());
            std::vector<int> seed_pcs = self->pc_selector->get_selected_pcs();

            std::vector<std::vector<int>> initial_sequence;
            if (!seed_pcs.empty()) {
                initial_sequence.push_back(seed_pcs);
            }

            CompositionPath best_composition = self->fractal_search_recursive(
                initial_sequence, 0, depth, branching_factor, key, edo, self->stop_requested
            );
            
            Fl::lock();
            if (self->stop_requested) {
                self->composition_buffer->text("Composition search stopped by user.");
            } else if (!best_composition.chords.empty()) {
                std::stringstream ss;
                ss << "Best Fractal Fluency Composition (FFS: " << std::fixed << std::setprecision(4) << best_composition.cumulative_ffs << "):\n\n";
                for (size_t i = 0; i < best_composition.chords.size(); ++i) {
                    ss << "Chord " << i + 1 << ": " << best_composition.chords[i].name << "\n";
                }
                self->composition_buffer->text(ss.str().c_str());
            } else {
                self->composition_buffer->text("No fluent composition found.");
            }
            self->generate_btn->activate();
            self->stop_btn->deactivate();
            self->search_running = false;
            self->progress_bar->value(100);
            Fl::unlock();
            Fl::awake();
        }).detach();
    }

    static void stop_cb(Fl_Widget*, void* data) {
        auto self = (AutomatedCompositionTab*)data;
        self->stop_requested = true;
    }
};

#endif // UI_COMPONENTS_HPP
