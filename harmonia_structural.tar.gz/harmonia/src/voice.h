#pragma once
#include <string>
#include <array>
#include <vector>
#include <cmath>
#include <atomic>

// ────────────────────────────────────────────────────────────────────────────
//  VOICE — a single additive-synthesis voice with a harmonic series.
//
//  Signal model:
//    y(t) = Σₖ  amplitude[k] · sin(2π · k · frequency · t + phase[k])
//
//  k=1 is the fundamental; k=2..MAX_HARMONICS are overtones.
//  The harmonic profile (amplitude[k]) encodes timbre.
// ────────────────────────────────────────────────────────────────────────────

constexpr int MAX_HARMONICS = 16;
constexpr double SAMPLE_RATE = 44100.0;

enum class TimbrePreset {
    SINE,       // only fundamental
    SAWTOOTH,   // 1/k rolloff
    SQUARE,     // odd harmonics 1/k
    STRINGS,    // 1/k with slight inharmonicity
    BRASS,      // rising then falling
    FLUTE,      // fundamental + weak second harmonic
    CUSTOM
};

struct Voice {
    // ── identity
    std::string name;
    int         id;           // unique across session

    // ── pitch
    double frequency;         // fundamental Hz (concert pitch A4=440)
    int    pitch_class;       // 0-11 (C=0, C#=1, ... B=11)
    int    octave;            // MIDI octave (4 = middle C octave)
    float  detune_cents;      // fine tuning in cents (−50 to +50)

    // ── amplitude / envelope
    float  amplitude;         // master gain 0..1
    float  attack_ms;         // ADSR
    float  decay_ms;
    float  sustain_level;
    float  release_ms;

    // ── harmonic series
    TimbrePreset timbre;
    std::array<float, MAX_HARMONICS> harmonic_amp;   // amplitude of kth harmonic
    std::array<float, MAX_HARMONICS> harmonic_phase;  // current phase (radians)
    std::array<float, MAX_HARMONICS> harmonic_phase_inc; // phase increment per sample

    // ── state
    std::atomic<bool> active{false};
    std::atomic<bool> note_on{false};
    float env_value{0.f};     // current envelope level
    enum class EnvStage { IDLE, ATTACK, DECAY, SUSTAIN, RELEASE } env_stage{EnvStage::IDLE};

    // ── Tonnetz coordinates (5-limit JI lattice)
    int tonnetz_x{0};   // fifths axis (×3/2)
    int tonnetz_y{0};   // thirds axis (×5/4)

    // ── display
    float color[3]{0.5f, 0.7f, 1.0f};   // RGB for UI

    // ────── construction
    Voice() {
        harmonic_amp.fill(0.f);
        harmonic_phase.fill(0.f);
        harmonic_phase_inc.fill(0.f);
        amplitude = 0.6f;
        attack_ms = 20.f; decay_ms = 80.f; sustain_level = 0.7f; release_ms = 300.f;
        timbre = TimbrePreset::STRINGS;
        setTimbre(timbre);
    }

    // ────── set frequency and recompute phase increments
    void setFrequency(double freq) {
        frequency = freq;
        double f_actual = freq * std::pow(2.0, detune_cents / 1200.0);
        for (int k = 1; k <= MAX_HARMONICS; k++) {
            harmonic_phase_inc[k-1] = static_cast<float>(
                2.0 * M_PI * k * f_actual / SAMPLE_RATE
            );
        }
        computeTonnetzCoords();
    }

    // ────── set pitch by MIDI note number
    void setMidiNote(int midi_note) {
        octave     = midi_note / 12 - 1;
        pitch_class = midi_note % 12;
        setFrequency(440.0 * std::pow(2.0, (midi_note - 69) / 12.0));
    }

    // ────── apply a timbre preset to harmonic amplitudes
    void setTimbre(TimbrePreset t) {
        timbre = t;
        harmonic_amp.fill(0.f);
        switch (t) {
        case TimbrePreset::SINE:
            harmonic_amp[0] = 1.0f;
            break;
        case TimbrePreset::SAWTOOTH:
            for (int k = 1; k <= MAX_HARMONICS; k++)
                harmonic_amp[k-1] = 1.0f / k;
            break;
        case TimbrePreset::SQUARE:
            for (int k = 1; k <= MAX_HARMONICS; k += 2)
                harmonic_amp[k-1] = 1.0f / k;
            break;
        case TimbrePreset::STRINGS:
            for (int k = 1; k <= MAX_HARMONICS; k++)
                harmonic_amp[k-1] = std::exp(-0.15f * (k-1)) / k;
            harmonic_amp[1] *= 1.4f;
            harmonic_amp[2] *= 1.1f;
            break;
        case TimbrePreset::BRASS:
            for (int k = 1; k <= MAX_HARMONICS; k++) {
                float env = (k <= 6) ? k/6.f : std::exp(-0.3f*(k-6));
                harmonic_amp[k-1] = env / std::sqrt(static_cast<float>(k));
            }
            break;
        case TimbrePreset::FLUTE:
            harmonic_amp[0] = 1.0f;
            harmonic_amp[1] = 0.3f;
            harmonic_amp[2] = 0.05f;
            break;
        case TimbrePreset::CUSTOM:
            break;
        }
        // normalize
        float peak = 0.f;
        for (float a : harmonic_amp) peak = std::max(peak, a);
        if (peak > 0.f) for (float& a : harmonic_amp) a /= peak;
    }

    // ────── map frequency to nearest Tonnetz coords (5-limit)
    void computeTonnetzCoords() {
        // project log2(f/C4) onto fifth (log2(3/2)) and third (log2(5/4)) axes
        // solving: a·log2(3/2) + b·log2(5/4) ≡ log2(f / reference)  mod 1
        double logf = std::log2(frequency / 261.63);
        logf = logf - std::floor(logf); // mod octave
        // grid search over (a,b) in [-5,5]x[-3,3]
        double best = 1e9;
        for (int a = -5; a <= 5; a++) {
            for (int b = -3; b <= 3; b++) {
                double val = a * std::log2(3.0/2.0) + b * std::log2(5.0/4.0);
                val = val - std::floor(val);
                double diff = std::min(std::abs(val - logf),
                             std::min(std::abs(val - logf + 1),
                                      std::abs(val - logf - 1)));
                if (diff < best) { best = diff; tonnetz_x = a; tonnetz_y = b; }
            }
        }
    }
};

// ────── note name utilities
static const char* NOTE_NAMES[12] = {
    "C","C#","D","D#","E","F","F#","G","G#","A","A#","B"
};

inline std::string noteName(int pitch_class, int octave) {
    return std::string(NOTE_NAMES[pitch_class]) + std::to_string(octave);
}

inline double midiToHz(int midi_note) {
    return 440.0 * std::pow(2.0, (midi_note - 69) / 12.0);
}

inline int hzToMidi(double hz) {
    return static_cast<int>(std::round(69.0 + 12.0 * std::log2(hz / 440.0)));
}
