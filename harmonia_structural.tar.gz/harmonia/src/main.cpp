/*
 * harmonia/src/main.cpp
 * ─────────────────────────────────────────────────────────────────────────────
 *  HARMONIA — Multi-voice psychoacoustic music coder
 *
 *  Window layout (1280 × 820):
 *  ┌──────────────────────────────────────────────────────────────────────────┐
 *  │  [Harmonia]  Key: C▼  EDO: 12▼  Master:━━━━  [Add Voice] [Play All]    │ ← toolbar
 *  ├─────────────────┬────────────────────────────┬───────────────────────────┤
 *  │                 │                            │                           │
 *  │   VOICE LIST    │      TONNETZ (OpenGL)      │   THEORY PANEL            │
 *  │   + controls    │                            │   • Next chords           │
 *  │                 │  Interactive harmonic       │   • Completion            │
 *  │  [voice strip]  │  lattice. Click=add note   │   • Orbifold dist         │
 *  │  [voice strip]  │  Middle-drag=pan           │   • EDO analysis          │
 *  │  ...            │  Scroll=zoom               │                           │
 *  │                 │                            │                           │
 *  ├─────────────────┴────────────────────────────┴───────────────────────────┤
 *  │  SPECTRUM + ROUGHNESS bar            OBJECT DISPLAY                      │ ← status
 *  └──────────────────────────────────────────────────────────────────────────┘
 */

#include <FL/Fl.H>
#include <FL/Fl_Double_Window.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Choice.H>
#include <FL/Fl_Value_Slider.H>
#include <FL/Fl_Scroll.H>
#include <FL/Fl_Output.H>
#include <FL/Fl_Input.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Light_Button.H>
#include <FL/Fl_Browser.H>
#include <FL/Fl_Spinner.H>
#include <FL/fl_draw.H>
#include <FL/Fl_Gl_Window.H>
#include <GL/gl.h>
#include <vector>
#include <string>
#include <sstream>
#include <memory>
#include <functional>
#include <map>
#include <cmath>
#include <cstdio>

#include "voice.h"
#include "audio_engine.h"
#include "tonnetz_widget.h"
#include "theory_bridge.h"

// ─────────────────────────────────────────────────────────────────────────────
//  FLTK colour helpers
// ─────────────────────────────────────────────────────────────────────────────
static Fl_Color flColor(float r, float g, float b) {
    return fl_rgb_color((uchar)(r*255),(uchar)(g*255),(uchar)(b*255));
}
static const Fl_Color COL_BG     = fl_rgb_color(18,20,28);
static const Fl_Color COL_PANEL  = fl_rgb_color(26,30,40);
static const Fl_Color COL_ACCENT = fl_rgb_color(200,160,40);
static const Fl_Color COL_TEXT   = fl_rgb_color(220,215,200);
static const Fl_Color COL_DIM    = fl_rgb_color(100,100,110);

// ─────────────────────────────────────────────────────────────────────────────
//  SPECTRUM DISPLAY — OpenGL widget showing partials per voice
// ─────────────────────────────────────────────────────────────────────────────
class SpectrumWidget : public Fl_Gl_Window {
public:
    SpectrumWidget(int X,int Y,int W,int H)
        : Fl_Gl_Window(X,Y,W,H)
    { mode(FL_RGB|FL_DOUBLE); }

    void update(const SpectrumSnapshot& snap, const std::vector<Voice>& voices,
                float roughness) {
        snap_ = snap; voices_ = voices; roughness_ = roughness; redraw();
    }

    void draw() override {
        if (!valid()) {
            glViewport(0,0,w(),h());
            glMatrixMode(GL_PROJECTION); glLoadIdentity();
            glOrtho(0,w(),h(),0,-1,1);
            glMatrixMode(GL_MODELVIEW); glLoadIdentity();
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
        }
        glClearColor(0.07f,0.08f,0.11f,1.f);
        glClear(GL_COLOR_BUFFER_BIT);

        // Draw spectrum bars
        int sw = w(), sh = h()-20;
        float bin_w = (float)sw / (SPECTRUM_SIZE/2);
        for (int i = 0; i < SPECTRUM_SIZE/2; i++) {
            float mag = snap_.magnitude[i];
            if (mag < 1e-5f) continue;
            float bh = std::min((float)sh, mag * sh * 3.f);
            // color by frequency
            float t = (float)i / (SPECTRUM_SIZE/2);
            float r = 0.2f + 0.8f*t, g = 0.7f - 0.5f*t, b = 1.f - 0.7f*t;
            glColor4f(r,g,b, 0.85f);
            glBegin(GL_QUADS);
            glVertex2f(i*bin_w, sh);
            glVertex2f((i+1)*bin_w, sh);
            glVertex2f((i+1)*bin_w, sh-bh);
            glVertex2f(i*bin_w, sh-bh);
            glEnd();
        }

        // Roughness bar at bottom
        float rw = roughness_ * sw;
        float rg = 1.f - roughness_;
        glColor4f(roughness_, rg, 0.f, 0.8f);
        glBegin(GL_QUADS);
        glVertex2f(0,sh); glVertex2f(rw,sh);
        glVertex2f(rw,h()); glVertex2f(0,h());
        glEnd();

        gl_font(FL_HELVETICA, 9);
        glColor3f(.6f,.6f,.6f);
        gl_draw("Roughness", 2, h()-3);
        char rbuf[32]; snprintf(rbuf,sizeof(rbuf),"%.2f", roughness_);
        gl_draw(rbuf, (int)(rw + 4), h()-3);

        // Freq axis labels
        glColor3f(.4f,.4f,.5f);
        static const int FREQ_MARKS[] = {100,200,500,1000,2000,4000,8000,0};
        for (int i = 0; FREQ_MARKS[i]; i++) {
            float f = FREQ_MARKS[i];
            float x = (f / (SAMPLE_RATE/2)) * sw;
            glBegin(GL_LINES); glVertex2f(x,sh); glVertex2f(x,sh-4); glEnd();
            char lbl[16]; snprintf(lbl,sizeof(lbl),"%d",FREQ_MARKS[i]);
            gl_draw(lbl, (int)x-8, sh-6);
        }
    }

private:
    SpectrumSnapshot snap_;
    std::vector<Voice> voices_;
    float roughness_{0.f};
};

// ─────────────────────────────────────────────────────────────────────────────
//  VOICE STRIP — one row per voice in the left panel
// ─────────────────────────────────────────────────────────────────────────────
struct VoiceStrip {
    int voice_id{-1};
    Fl_Group*       group{nullptr};
    Fl_Light_Button* btn_on{nullptr};
    Fl_Box*          lbl_note{nullptr};
    Fl_Value_Slider* sl_amp{nullptr};
    Fl_Value_Slider* sl_detune{nullptr};
    Fl_Choice*       ch_timbre{nullptr};
    Fl_Button*       btn_remove{nullptr};
    Fl_Box*          roughness_box{nullptr};
    float            roughness_val{0.f};
    float            color[3]{0.5f,0.7f,1.f};
};

// ─────────────────────────────────────────────────────────────────────────────
//  MAIN WINDOW
// ─────────────────────────────────────────────────────────────────────────────
class HarmoniaApp {
public:
    HarmoniaApp();
    ~HarmoniaApp();
    void run();

private:
    static constexpr int WIN_W = 1280, WIN_H = 820;
    static constexpr int TOOLBAR_H = 38;
    static constexpr int VOICE_PANEL_W = 260;
    static constexpr int THEORY_PANEL_W = 300;
    static constexpr int STATUS_H = 120;
    static constexpr int TONNETZ_W = WIN_W - VOICE_PANEL_W - THEORY_PANEL_W;
    static constexpr int TONNETZ_H = WIN_H - TOOLBAR_H - STATUS_H;

    // ── FLTK widgets
    Fl_Double_Window* win_{nullptr};

    // Toolbar
    Fl_Button*       btn_add_{nullptr};
    Fl_Button*       btn_play_all_{nullptr};
    Fl_Button*       btn_stop_all_{nullptr};
    Fl_Choice*       ch_key_{nullptr};
    Fl_Spinner*      sp_edo_{nullptr};
    Fl_Value_Slider* sl_master_{nullptr};
    Fl_Output*       out_object_{nullptr};

    // Left panel – voice list
    Fl_Scroll*        scroll_voices_{nullptr};
    std::vector<VoiceStrip*> strips_;
    int               voice_panel_y_{0};  // next y for new strip

    // Centre – Tonnetz
    TonnetzWidget*    tonnetz_{nullptr};

    // Right – structural theory panel
    Fl_Browser*  browser_function_{nullptr};    // function + algebraic reasons
    Fl_Browser*  browser_resolutions_{nullptr}; // resolution paths with justification
    Fl_Browser*  browser_completion_{nullptr};  // completion suggestions + reasons
    Fl_Browser*  browser_edo_{nullptr};
    Fl_Button*   btn_analyze_{nullptr};
    Fl_Button*   btn_resolve_{nullptr};
    Fl_Button*   btn_complete_{nullptr};
    Fl_Button*   btn_edo_{nullptr};
    Fl_Output*   out_orbifold_{nullptr};

    // Bottom – spectrum + roughness
    SpectrumWidget*   spectrum_{nullptr};
    Fl_Box*           box_object_label_{nullptr};

    // ── engines
    std::unique_ptr<AudioEngine>  audio_;
    std::unique_ptr<TheoryBridge> theory_;

    // ── state
    int  current_key_{0};
    int  current_edo_{12};
    int  last_clicked_root_{-1};
    std::string last_chord_type_{"maj"};
    FunctionalAnalysis  last_func_;
    TonnetzTension      last_tension_;
    std::vector<ResolutionPath> last_resolutions_;

    // ── methods
    void buildUI();
    void setupCallbacks();

    // Voice management
    void addVoice(int midi_note = 60, TimbrePreset t = TimbrePreset::STRINGS);
    void removeVoice(int voice_id);
    VoiceStrip* findStrip(int voice_id);
    void relayoutStrips();

    // Structural theory updates
    void updateFunctionalAnalysis();
    void updateResolutionPaths();
    void updateCompletionSuggestions();
    void updateEDOAnalysis();

    static void onIdle(void* data);
    static void cbAddVoice(Fl_Widget*, void* d) { ((HarmoniaApp*)d)->addVoice(); }
    static void cbPlayAll(Fl_Widget*, void* d);
    static void cbStopAll(Fl_Widget*, void* d);
    static void cbMasterVol(Fl_Widget*, void* d);
    static void cbKey(Fl_Widget*, void* d);
    static void cbEDO(Fl_Widget*, void* d);
    static void cbAnalyze(Fl_Widget*, void* d);
    static void cbResolve(Fl_Widget*, void* d);
    static void cbSuggestCompletion(Fl_Widget*, void* d);
    static void cbAnalyseEDO(Fl_Widget*, void* d);

    // Voice strip callbacks
    static void cbVoiceOn(Fl_Widget* w, void* d);
    static void cbVoiceAmp(Fl_Widget* w, void* d);
    static void cbVoiceDetune(Fl_Widget* w, void* d);
    static void cbVoiceTimbre(Fl_Widget* w, void* d);
    static void cbVoiceRemove(Fl_Widget* w, void* d);

    // Tonnetz click
    void onTonnetzClick(int pitch_class, int tx, int ty);

    std::string theoryDir_;
};

// ─────────────────────────────────────────────────────────────────────────────
HarmoniaApp::HarmoniaApp() {
    audio_  = std::make_unique<AudioEngine>();
    theory_ = std::make_unique<TheoryBridge>();
    buildUI();
    setupCallbacks();
}

HarmoniaApp::~HarmoniaApp() {
    audio_->shutdown();
    theory_->stop();
}

void HarmoniaApp::run() {
    // ── start audio (ALSA)
    if (!audio_->init()) {
        fl_message("ALSA init failed — audio disabled");
    }

    // ── find theory server
    char exepath[512] = {};
    ssize_t n = readlink("/proc/self/exe", exepath, sizeof(exepath)-1);
    if (n > 0) {
        std::string dir(exepath, n);
        size_t pos = dir.rfind('/');
        theoryDir_ = dir.substr(0, pos) + "/../theory";
    } else {
        theoryDir_ = "./theory";
    }

    if (!theory_->start(theoryDir_)) {
        fl_message("Python theory server not started — theory features disabled");
    }

    // ── seed with a C major chord
    addVoice(60, TimbrePreset::STRINGS);  // C4
    addVoice(64, TimbrePreset::STRINGS);  // E4
    addVoice(67, TimbrePreset::STRINGS);  // G4

    // ── play them
    for (auto& s : strips_) audio_->noteOn(s->voice_id);

    // ── initial structural analysis
    updateFunctionalAnalysis();

    Fl::add_idle(onIdle, this);
    Fl::run();
}

// ─────────────────────────────────────────────────────────────────────────────
//  UI CONSTRUCTION
// ─────────────────────────────────────────────────────────────────────────────
void HarmoniaApp::buildUI() {
    Fl::scheme("gtk+");
    Fl::background(18,20,28);
    Fl::foreground(220,215,200);

    win_ = new Fl_Double_Window(WIN_W, WIN_H, "Harmonia — Psychoacoustic Music Coder");
    win_->color(COL_BG);

    // ── TOOLBAR ──────────────────────────────────────────────────────────────
    {
        Fl_Group* tb = new Fl_Group(0, 0, WIN_W, TOOLBAR_H);
        tb->box(FL_FLAT_BOX); tb->color(fl_rgb_color(14,16,22));

        int x = 8, y = 6, bh = 26;

        Fl_Box* title = new Fl_Box(x,y,100,bh,"HARMONIA");
        title->labelcolor(COL_ACCENT); title->labelfont(FL_HELVETICA_BOLD);
        title->labelsize(14); title->box(FL_NO_BOX);
        x += 108;

        new Fl_Box(x,y,30,bh,"Key:"); x+=30;
        ch_key_ = new Fl_Choice(x,y,70,bh);
        for (int i=0;i<12;i++) ch_key_->add(NOTE_NAMES[i]);
        ch_key_->value(0); x += 76;

        new Fl_Box(x,y,30,bh,"EDO:"); x+=32;
        sp_edo_ = new Fl_Spinner(x,y,60,bh);
        sp_edo_->minimum(5); sp_edo_->maximum(72); sp_edo_->value(12);
        x += 68;

        new Fl_Box(x,y,50,bh,"Master:"); x+=52;
        sl_master_ = new Fl_Value_Slider(x,y,100,bh);
        sl_master_->type(FL_HORIZONTAL); sl_master_->minimum(0); sl_master_->maximum(1);
        sl_master_->value(0.5); sl_master_->color(fl_rgb_color(40,44,58));
        x += 110;

        btn_add_ = new Fl_Button(x,y,90,bh,"+ Add Voice");
        btn_add_->color(fl_rgb_color(30,80,50)); btn_add_->labelcolor(fl_rgb_color(120,220,100));
        x += 98;

        btn_play_all_ = new Fl_Button(x,y,70,bh,"▶ All");
        btn_play_all_->color(fl_rgb_color(30,60,100)); btn_play_all_->labelcolor(fl_rgb_color(100,180,255));
        x += 76;

        btn_stop_all_ = new Fl_Button(x,y,70,bh,"■ Stop");
        btn_stop_all_->color(fl_rgb_color(80,30,30)); btn_stop_all_->labelcolor(fl_rgb_color(255,120,100));
        x += 76;

        out_object_ = new Fl_Output(x,y, WIN_W-x-8, bh);
        out_object_->box(FL_FLAT_BOX); out_object_->color(fl_rgb_color(20,24,32));
        out_object_->textcolor(COL_ACCENT); out_object_->textsize(13);
        out_object_->value("Object: —");

        tb->end();
    }

    int content_y = TOOLBAR_H;
    int content_h = WIN_H - TOOLBAR_H - STATUS_H;

    // ── VOICE PANEL (left) ────────────────────────────────────────────────────
    {
        Fl_Group* panel = new Fl_Group(0, content_y, VOICE_PANEL_W, content_h);
        panel->box(FL_FLAT_BOX); panel->color(fl_rgb_color(22,26,35));

        Fl_Box* hdr = new Fl_Box(0,content_y, VOICE_PANEL_W,22,"VOICES");
        hdr->box(FL_FLAT_BOX); hdr->color(fl_rgb_color(30,34,46));
        hdr->labelcolor(COL_DIM); hdr->labelfont(FL_HELVETICA); hdr->labelsize(10);

        scroll_voices_ = new Fl_Scroll(0, content_y+22, VOICE_PANEL_W, content_h-22);
        scroll_voices_->box(FL_FLAT_BOX); scroll_voices_->color(fl_rgb_color(22,26,35));
        scroll_voices_->type(Fl_Scroll::VERTICAL_ALWAYS);
        scroll_voices_->end();

        voice_panel_y_ = content_y + 22;
        panel->end();
    }

    // ── TONNETZ (centre) ──────────────────────────────────────────────────────
    {
        tonnetz_ = new TonnetzWidget(VOICE_PANEL_W, content_y, TONNETZ_W, content_h);
    }

    // ── THEORY PANEL (right) — STRUCTURAL EDITION ────────────────────────────
    {
        int tx = VOICE_PANEL_W + TONNETZ_W;
        Fl_Group* panel = new Fl_Group(tx, content_y, THEORY_PANEL_W, content_h);
        panel->box(FL_FLAT_BOX); panel->color(fl_rgb_color(22,26,35));

        int py = content_y+4, pw = THEORY_PANEL_W-8, px = tx+4;

        // ─ Functional Analysis
        auto* h1 = new Fl_Box(px,py,pw,16,"HARMONIC FUNCTION");
        h1->labelfont(FL_HELVETICA_BOLD); h1->labelsize(9);
        h1->labelcolor(COL_ACCENT); h1->box(FL_NO_BOX); py+=18;

        browser_function_ = new Fl_Browser(px,py,pw,130);
        browser_function_->textsize(9); browser_function_->color(fl_rgb_color(18,22,30));
        browser_function_->textcolor(COL_TEXT); py+=132;

        btn_analyze_ = new Fl_Button(px,py,pw,20,"Analyse chord structure");
        btn_analyze_->labelsize(9); btn_analyze_->color(fl_rgb_color(30,50,80)); py+=24;

        // ─ Resolution Paths
        auto* h2 = new Fl_Box(px,py,pw,16,"RESOLUTION PATHS");
        h2->labelfont(FL_HELVETICA_BOLD); h2->labelsize(9);
        h2->labelcolor(fl_rgb_color(200,120,60)); h2->box(FL_NO_BOX); py+=18;

        browser_resolutions_ = new Fl_Browser(px,py,pw,140);
        browser_resolutions_->textsize(9); browser_resolutions_->color(fl_rgb_color(18,22,30));
        browser_resolutions_->textcolor(fl_rgb_color(220,200,170)); py+=142;

        btn_resolve_ = new Fl_Button(px,py,pw,20,"Show resolution paths");
        btn_resolve_->labelsize(9); btn_resolve_->color(fl_rgb_color(50,30,20)); py+=24;

        // ─ Voice Completion
        auto* h3 = new Fl_Box(px,py,pw,16,"COMPLETION SUGGESTIONS");
        h3->labelfont(FL_HELVETICA_BOLD); h3->labelsize(9);
        h3->labelcolor(fl_rgb_color(100,200,140)); h3->box(FL_NO_BOX); py+=18;

        browser_completion_ = new Fl_Browser(px,py,pw,120);
        browser_completion_->textsize(9); browser_completion_->color(fl_rgb_color(18,22,30));
        browser_completion_->textcolor(fl_rgb_color(160,220,180)); py+=122;

        auto* btn_comp = new Fl_Button(px,py,pw,20,"Suggest next voice");
        btn_comp->labelsize(9); btn_comp->color(fl_rgb_color(20,50,30));
        btn_comp->callback(cbSuggestCompletion, this); py+=24;

        // ─ Orbifold distance
        out_orbifold_ = new Fl_Output(px,py,pw,30);
        out_orbifold_->textsize(9); out_orbifold_->color(fl_rgb_color(18,22,30));
        out_orbifold_->textcolor(fl_rgb_color(150,200,150)); py+=34;

        // ─ EDO analysis
        auto* h4 = new Fl_Box(px,py,pw,16,"EDO ANALYSIS");
        h4->labelfont(FL_HELVETICA_BOLD); h4->labelsize(9);
        h4->labelcolor(fl_rgb_color(140,100,220)); h4->box(FL_NO_BOX); py+=18;

        browser_edo_ = new Fl_Browser(px,py,pw, content_h-(py-content_y)-28);
        browser_edo_->textsize(9); browser_edo_->color(fl_rgb_color(18,22,30));
        browser_edo_->textcolor(fl_rgb_color(180,160,220));
        py = content_y+content_h-26;

        btn_edo_ = new Fl_Button(px,py,pw,22,"Analyse EDO");
        btn_edo_->labelsize(9); btn_edo_->color(fl_rgb_color(40,25,70));
        btn_edo_->callback(cbAnalyseEDO, this);

        panel->end();
    }

    // ── STATUS / SPECTRUM BAR (bottom) ────────────────────────────────────────
    {
        int sy = WIN_H - STATUS_H;
        Fl_Group* sb = new Fl_Group(0,sy, WIN_W, STATUS_H);
        sb->box(FL_FLAT_BOX); sb->color(fl_rgb_color(14,16,22));

        spectrum_ = new SpectrumWidget(0, sy, WIN_W - 250, STATUS_H);

        box_object_label_ = new Fl_Box(WIN_W-248, sy, 248, STATUS_H, "");
        box_object_label_->box(FL_FLAT_BOX); box_object_label_->color(fl_rgb_color(18,22,30));
        box_object_label_->labelcolor(COL_ACCENT); box_object_label_->labelfont(FL_HELVETICA_BOLD);
        box_object_label_->labelsize(16); box_object_label_->align(FL_ALIGN_CENTER|FL_ALIGN_INSIDE);

        sb->end();
    }

    win_->end();
    win_->show();
}

// ─────────────────────────────────────────────────────────────────────────────
void HarmoniaApp::setupCallbacks() {
    btn_add_->callback(cbAddVoice, this);
    btn_play_all_->callback(cbPlayAll, this);
    btn_stop_all_->callback(cbStopAll, this);
    sl_master_->callback(cbMasterVol, this);
    ch_key_->callback(cbKey, this);
    sp_edo_->callback(cbEDO, this);
    if (btn_analyze_) btn_analyze_->callback(cbAnalyze, this);
    if (btn_resolve_) btn_resolve_->callback(cbResolve, this);

    tonnetz_->setNodeClickCallback([this](int pc, int tx, int ty){
        onTonnetzClick(pc, tx, ty);
    });
}

// ─────────────────────────────────────────────────────────────────────────────
//  VOICE MANAGEMENT
// ─────────────────────────────────────────────────────────────────────────────
void HarmoniaApp::addVoice(int midi_note, TimbrePreset t) {
    int id = audio_->addVoice(midi_note, t);
    if (id < 0) { fl_message("Max voices reached"); return; }

    static const int STRIP_H = 72;
    int sw = VOICE_PANEL_W - 12;

    // Compute y inside scroll
    int yrel = 0;
    for (auto& s : strips_) yrel += STRIP_H + 2;

    scroll_voices_->begin();
    VoiceStrip* strip = new VoiceStrip();
    strip->voice_id = id;

    int gx = 4, gy = scroll_voices_->y() + yrel + 2;
    strip->group = new Fl_Group(gx, gy, sw, STRIP_H);
    strip->group->box(FL_FLAT_BOX);
    strip->group->color(fl_rgb_color(28,32,44));

    // Note label
    strip->lbl_note = new Fl_Box(gx+2, gy+2, 52, 20, "—");
    strip->lbl_note->box(FL_FLAT_BOX);
    strip->lbl_note->color(fl_rgb_color(14,16,22));
    strip->lbl_note->labelcolor(COL_TEXT);
    strip->lbl_note->labelfont(FL_HELVETICA_BOLD);
    strip->lbl_note->labelsize(13);

    // On/Off
    strip->btn_on = new Fl_Light_Button(gx+58, gy+2, 44, 20, "ON");
    strip->btn_on->labelsize(10);
    strip->btn_on->value(0);
    strip->btn_on->user_data((void*)(intptr_t)id);
    strip->btn_on->callback(cbVoiceOn, this);

    // Remove
    strip->btn_remove = new Fl_Button(gx+sw-26, gy+2, 22, 20, "×");
    strip->btn_remove->labelsize(13);
    strip->btn_remove->color(fl_rgb_color(80,24,24));
    strip->btn_remove->labelcolor(fl_rgb_color(255,100,100));
    strip->btn_remove->user_data((void*)(intptr_t)id);
    strip->btn_remove->callback(cbVoiceRemove, this);

    // Amplitude slider
    new Fl_Box(gx+2, gy+24, 30, 14, "Amp");
    ((Fl_Box*)Fl::focus())->labelsize(9);
    strip->sl_amp = new Fl_Value_Slider(gx+34, gy+24, sw-60, 14);
    strip->sl_amp->type(FL_HORIZONTAL); strip->sl_amp->minimum(0); strip->sl_amp->maximum(1);
    strip->sl_amp->value(0.6); strip->sl_amp->textsize(8);
    strip->sl_amp->user_data((void*)(intptr_t)id);
    strip->sl_amp->callback(cbVoiceAmp, this);

    // Detune slider
    new Fl_Box(gx+2, gy+40, 30, 14, "Det");
    strip->sl_detune = new Fl_Value_Slider(gx+34, gy+40, sw-60, 14);
    strip->sl_detune->type(FL_HORIZONTAL); strip->sl_detune->minimum(-50); strip->sl_detune->maximum(50);
    strip->sl_detune->value(0); strip->sl_detune->textsize(8);
    strip->sl_detune->user_data((void*)(intptr_t)id);
    strip->sl_detune->callback(cbVoiceDetune, this);

    // Timbre choice
    strip->ch_timbre = new Fl_Choice(gx+2, gy+56, sw-4, 14);
    strip->ch_timbre->textsize(9);
    strip->ch_timbre->add("Sine|Sawtooth|Square|Strings|Brass|Flute");
    strip->ch_timbre->value(3);  // Strings
    strip->ch_timbre->user_data((void*)(intptr_t)id);
    strip->ch_timbre->callback(cbVoiceTimbre, this);

    // Roughness indicator box
    strip->roughness_box = new Fl_Box(gx+104, gy+2, 50, 20, "");
    strip->roughness_box->box(FL_FLAT_BOX);
    strip->roughness_box->color(fl_rgb_color(14,16,22));
    strip->roughness_box->labelcolor(COL_TEXT); strip->roughness_box->labelsize(9);

    strip->group->end();
    scroll_voices_->end();

    // Update note label
    auto voices = audio_->getVoiceSnapshot();
    for (auto& v : voices) {
        if (v.id == id) {
            strip->color[0] = v.color[0]; strip->color[1] = v.color[1]; strip->color[2] = v.color[2];
            char buf[16];
            snprintf(buf,sizeof(buf),"%s%d", NOTE_NAMES[v.pitch_class], v.octave);
            strip->lbl_note->label(buf);
            strip->lbl_note->copy_label(buf);
            strip->group->color(flColor(v.color[0]*0.15f, v.color[1]*0.15f, v.color[2]*0.15f));
        }
    }

    strips_.push_back(strip);
    scroll_voices_->redraw();
    win_->redraw();
}

void HarmoniaApp::removeVoice(int voice_id) {
    audio_->noteOff(voice_id);
    audio_->removeVoice(voice_id);

    auto it = std::find_if(strips_.begin(), strips_.end(),
        [voice_id](VoiceStrip* s){ return s->voice_id == voice_id; });
    if (it != strips_.end()) {
        scroll_voices_->remove((*it)->group);
        Fl::delete_widget((*it)->group);
        delete *it;
        strips_.erase(it);
    }
    relayoutStrips();
    scroll_voices_->redraw();
}

void HarmoniaApp::relayoutStrips() {
    static const int STRIP_H = 72;
    int y = scroll_voices_->y() + 2;
    for (auto* s : strips_) {
        int dy = y - s->group->y();
        s->group->position(s->group->x(), y);
        y += STRIP_H + 2;
    }
}

VoiceStrip* HarmoniaApp::findStrip(int voice_id) {
    for (auto* s : strips_) if (s->voice_id == voice_id) return s;
    return nullptr;
}

// ─────────────────────────────────────────────────────────────────────────────
//  IDLE — update UI from audio thread results
// ─────────────────────────────────────────────────────────────────────────────
void HarmoniaApp::onIdle(void* data) {
    HarmoniaApp* app = (HarmoniaApp*)data;

    // ── poll theory bridge callbacks
    app->theory_->poll();

    // ── update spectrum + roughness
    auto snap   = app->audio_->getSpectrumSnapshot();
    auto voices = app->audio_->getVoiceSnapshot();
    auto rr     = app->audio_->getRoughnessSnapshot();
    auto obj    = app->audio_->getAbstractObject();

    float total_rough = 0.f;
    for (auto& r : rr) total_rough += r.roughness;
    app->spectrum_->update(snap, voices, std::min(1.f, total_rough));

    // ── Update Tonnetz
    app->tonnetz_->setVoices(voices);
    app->tonnetz_->setAbstractObject(obj);
    app->tonnetz_->setRoughnessRecords(rr);

    // ── Update abstract object display
    if (obj.confidence > 0.2f) {
        char buf[256];
        snprintf(buf,sizeof(buf), "%s  [vp=%.0fHz]  R=%.2f",
                 obj.chord_name.c_str(), obj.virtual_pitch_hz, obj.roughness_total);
        app->out_object_->value(buf);
        app->box_object_label_->copy_label(obj.chord_name.c_str());

        // Update orbifold display with VL cost
        snprintf(buf, sizeof(buf), "Tonnetz dist from tonic: see Resolve panel");
        if (app->out_orbifold_) app->out_orbifold_->value(buf);
    }

    // ── Update roughness on each voice strip
    std::map<int,float> voice_rough;
    for (auto& r : rr) {
        voice_rough[r.voice_a] += r.roughness;
        voice_rough[r.voice_b] += r.roughness;
    }
    for (auto* s : app->strips_) {
        float rv = voice_rough.count(s->voice_id) ? voice_rough[s->voice_id] : 0.f;
        s->roughness_val = rv;
        char rbuf[16]; snprintf(rbuf,sizeof(rbuf),"R:%.2f",rv);
        s->roughness_box->copy_label(rbuf);
        float rn = std::min(1.f, rv);
        s->roughness_box->color(fl_rgb_color((uchar)(rn*200),(uchar)((1-rn)*160),40));
        s->roughness_box->redraw();
    }

    Fl::check();
}

// ─────────────────────────────────────────────────────────────────────────────
//  TONNETZ CLICK — add voice at clicked pitch class
// ─────────────────────────────────────────────────────────────────────────────
void HarmoniaApp::onTonnetzClick(int pitch_class, int tx, int ty) {
    int midi = 60 + ((pitch_class - 60%12 + 12) % 12);
    if (midi < 48) midi += 12;
    if (midi > 84) midi -= 12;

    last_clicked_root_ = pitch_class;
    auto voices = audio_->getVoiceSnapshot();

    bool found = false;
    for (auto& v : voices) {
        if (v.active && v.pitch_class == pitch_class) {
            audio_->noteOff(v.id); found = true; break;
        }
    }
    if (!found) {
        addVoice(midi);
        if (!strips_.empty()) {
            int newid = strips_.back()->voice_id;
            audio_->noteOn(newid);
            if (auto* s = findStrip(newid)) s->btn_on->value(1);
        }
    }

    updateFunctionalAnalysis();
    updateCompletionSuggestions();
}

// ─────────────────────────────────────────────────────────────────────────────
//  STRUCTURAL THEORY UPDATES
// ─────────────────────────────────────────────────────────────────────────────

void HarmoniaApp::updateFunctionalAnalysis() {
    auto voices = audio_->getVoiceSnapshot();
    std::vector<int> pcs;
    for (auto& v : voices) if (v.active) pcs.push_back(v.pitch_class);
    if (pcs.empty()) return;

    theory_->queryAnalyzeChord(pcs, current_key_,
        [this](const FunctionalAnalysis& fa, const TonnetzTension& tt) {
            last_func_    = fa;
            last_tension_ = tt;

            browser_function_->clear();

            // ── Function + reason
            char buf[256];
            static const char* FUNC_COLORS[] = {
                "@C6", "@C4", "@C7", "@C3", "@C2", "@C1"
            };
            // function badge
            snprintf(buf,sizeof(buf),"@b%s  [tension=%d]  dist=%.2f",
                     fa.function.c_str(), fa.tension_level, tt.distance);
            browser_function_->add(buf);

            // truncated reason (split into lines)
            std::string reason = fa.function_reason;
            while (reason.size() > 50) {
                size_t split = reason.rfind(' ', 50);
                if (split == std::string::npos) split = 50;
                browser_function_->add(("  " + reason.substr(0,split)).c_str());
                reason = reason.substr(split+1);
            }
            if (!reason.empty()) browser_function_->add(("  " + reason).c_str());

            // ── Set class
            // We get this from the same analyze_chord call via raw query
            browser_function_->add("  —");

            // ── Tritone
            if (fa.has_tritone && fa.tritone.size() >= 2) {
                snprintf(buf,sizeof(buf),"  Tritone: %s-%s  (resolves inward)",
                         fa.tritone_names.size()>=2
                             ? fa.tritone_names[0].c_str() : "?",
                         fa.tritone_names.size()>=2
                             ? fa.tritone_names[1].c_str() : "?");
                browser_function_->add(buf);
            }

            // ── Tendency tones
            if (!fa.tendency_tones.empty()) {
                browser_function_->add("  Tendency tones:");
                for (auto& t : fa.tendency_tones) {
                    snprintf(buf,sizeof(buf),"   %s (%s) -> %s [%s]",
                             t.name.c_str(), t.role.c_str(),
                             t.tendency.c_str(), t.force.c_str());
                    browser_function_->add(buf);
                }
            }

            // ── Tension bar (text)
            snprintf(buf,sizeof(buf),"  Tension: %s (%.0f%%)",
                     tt.tension_label.c_str(), tt.tension*100.f);
            browser_function_->add(buf);

            browser_function_->redraw();
        });

    // Also request set-class info for ICV
    std::string pcs_json = "[";
    for (size_t i=0;i<pcs.size();i++) {
        pcs_json += std::to_string(pcs[i]);
        if (i+1<pcs.size()) pcs_json += ",";
    }
    pcs_json += "]";
    theory_->queryRaw(
        "{\"cmd\":\"analyze_chord\",\"pcs\":" + pcs_json +
        ",\"key\":" + std::to_string(current_key_) + "}",
        "analyze_chord_icv",  // separate tag so it doesn't conflict
        [this](const std::string& resp) {
            // Extract ICV and forte number
            // find ic_description
            size_t p = resp.find("ic_description");
            if (p == std::string::npos) return;
            size_t qs = resp.find('"', p+16);
            size_t qe = resp.find('"', qs+1);
            if (qs==std::string::npos||qe==std::string::npos) return;
            std::string ic_desc = resp.substr(qs+1, qe-qs-1);
            std::string forte   = TheoryBridge::jStr(resp,"forte","?");
            std::string cname   = TheoryBridge::jStr(resp,"common_name","");
            char buf[128];
            snprintf(buf,sizeof(buf),"  Forte: %s  (%s)", forte.c_str(), cname.c_str());
            if (browser_function_) browser_function_->insert(3, buf);
            snprintf(buf,sizeof(buf),"  ICV:   [%s]", ic_desc.c_str());
            if (browser_function_) browser_function_->insert(4, buf);
            browser_function_->redraw();
        });
}

void HarmoniaApp::updateResolutionPaths() {
    auto obj = audio_->getAbstractObject();
    if (obj.root_pc < 0 && last_clicked_root_ < 0) return;
    int root = last_clicked_root_ >= 0 ? last_clicked_root_ : obj.root_pc;
    std::string qual = "maj";  // default; ideally from identified chord

    theory_->queryResolutionPaths(root, qual, current_key_,
        [this](const std::vector<ResolutionPath>& paths) {
            last_resolutions_ = paths;
            browser_resolutions_->clear();

            // Build Tonnetz progression path for visualization
            std::vector<std::pair<int,int>> tpath;

            static const char* RULE_COLORS[5] = {
                "@C1","@C3","@C4","@C6","@C7"
            };
            for (auto& rp : paths) {
                char buf[256];
                // Rule class badge
                const char* col = (rp.rule_class == "necessity") ? "@C1" :
                                  (rp.rule_class == "minimal_motion") ? "@C4" : "@C6";
                snprintf(buf,sizeof(buf),"%s[P%d] %s -> %s (%s, VL=%d)",
                         col, rp.priority,
                         rp.rule.c_str(),
                         rp.target_label.c_str(),
                         rp.voice_leading.smoothness.c_str(),
                         rp.voice_leading.distance);
                browser_resolutions_->add(buf);

                // Explanation (word-wrapped)
                std::string ex = rp.explanation;
                if (ex.size() > 48) ex = ex.substr(0,48) + "...";
                browser_resolutions_->add(("  " + ex).c_str());

                // Voice motions
                for (auto& m : rp.voice_leading.motions) {
                    if (m.semitones == 0) continue;
                    snprintf(buf,sizeof(buf),"   %s->%s (%+d)",
                             m.from_name.c_str(), m.to_name.c_str(), m.semitones);
                    browser_resolutions_->add(buf);
                }
                browser_resolutions_->add(" ");
            }
            browser_resolutions_->redraw();
        });
}

void HarmoniaApp::updateCompletionSuggestions() {
    auto voices = audio_->getVoiceSnapshot();
    std::vector<int> pcs;
    for (auto& v : voices) if (v.active) pcs.push_back(v.pitch_class);

    theory_->querySuggestCompletion(pcs, current_key_,
        [this](const std::vector<CompletionSuggestion>& ns) {
            browser_completion_->clear();
            for (auto& s : ns) {
                char buf[128];
                // Score bar
                int bars = (int)(s.score * 8);
                std::string bar(bars, '|');
                snprintf(buf,sizeof(buf),"@b%-3s  %s  R+%.2f  %s",
                         s.name.c_str(), bar.c_str(),
                         s.roughness_delta,
                         s.in_key ? "(diatonic)" : "(chromatic)");
                browser_completion_->add(buf);
                // Structural reasons
                for (auto& r : s.structural_reasons) {
                    browser_completion_->add(("   " + r).c_str());
                }
                if (!s.structural_reasons.empty())
                    browser_completion_->add(" ");
            }
            browser_completion_->redraw();
        });
}

void HarmoniaApp::updateEDOAnalysis() {
    theory_->queryEDOAnalysis(current_edo_,
        [this](const std::string& raw) {
            browser_edo_->clear();
            char buf[128];
            snprintf(buf,sizeof(buf),"EDO-%d  step=%.2f¢",
                     current_edo_, TheoryBridge::jFloat(raw,"step_cents"));
            browser_edo_->add(buf);
            snprintf(buf,sizeof(buf),"5-limit score: %.1f%%",
                     TheoryBridge::jFloat(raw,"consonance_score"));
            browser_edo_->add(buf);
            snprintf(buf,sizeof(buf),"7-limit score: %.1f%%",
                     TheoryBridge::jFloat(raw,"seven_limit_score"));
            browser_edo_->add(buf);
            browser_edo_->add("  — Prime errors from JI —");

            static const struct { const char* prime; const char* name; } PRIMES[] = {
                {"3","P5/P4"},{"5","M3/m6"},{"7","h7"},{"11","11th"},{"13","13th"},{nullptr,nullptr}
            };
            for (int i=0; PRIMES[i].prime; i++) {
                size_t p = raw.find(std::string("\"")+PRIMES[i].prime+"\"");
                if (p==std::string::npos) continue;
                size_t ep = raw.find("error_cents",p);
                if (ep==std::string::npos) continue;
                ep = raw.find_first_of("0123456789-.",ep+11);
                size_t ee = raw.find_first_not_of("0123456789-.",ep);
                std::string err = raw.substr(ep, ee-ep);
                float ev = std::stof(err);
                snprintf(buf,sizeof(buf),"  prime %s (%s):  %+.2f¢",
                         PRIMES[i].prime, PRIMES[i].name, ev);
                browser_edo_->add(buf);
            }
            browser_edo_->redraw();
        });
}

// ─────────────────────────────────────────────────────────────────────────────
//  STATIC CALLBACKS
// ─────────────────────────────────────────────────────────────────────────────
void HarmoniaApp::cbPlayAll(Fl_Widget*, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    for (auto* s : app->strips_) {
        app->audio_->noteOn(s->voice_id);
        s->btn_on->value(1);
    }
}

void HarmoniaApp::cbStopAll(Fl_Widget*, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    for (auto* s : app->strips_) {
        app->audio_->noteOff(s->voice_id);
        s->btn_on->value(0);
    }
}

void HarmoniaApp::cbMasterVol(Fl_Widget* w, void* d) {
    ((HarmoniaApp*)d)->audio_->setMasterVolume((float)((Fl_Value_Slider*)w)->value());
}

void HarmoniaApp::cbKey(Fl_Widget*, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    app->current_key_ = app->ch_key_->value();
    app->updateFunctionalAnalysis();
}

void HarmoniaApp::cbEDO(Fl_Widget*, void* d) {
    ((HarmoniaApp*)d)->current_edo_ = (int)((HarmoniaApp*)d)->sp_edo_->value();
}

void HarmoniaApp::cbAnalyze(Fl_Widget*, void* d) {
    ((HarmoniaApp*)d)->updateFunctionalAnalysis();
}

void HarmoniaApp::cbResolve(Fl_Widget*, void* d) {
    ((HarmoniaApp*)d)->updateResolutionPaths();
}

void HarmoniaApp::cbSuggestCompletion(Fl_Widget*, void* d) {
    ((HarmoniaApp*)d)->updateCompletionSuggestions();
}

void HarmoniaApp::cbAnalyseEDO(Fl_Widget*, void* d) {
    ((HarmoniaApp*)d)->updateEDOAnalysis();
}

void HarmoniaApp::cbVoiceOn(Fl_Widget* w, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    int id = (int)(intptr_t)w->user_data();
    Fl_Light_Button* btn = (Fl_Light_Button*)w;
    if (btn->value()) app->audio_->noteOn(id);
    else              app->audio_->noteOff(id);
}

void HarmoniaApp::cbVoiceAmp(Fl_Widget* w, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    int id = (int)(intptr_t)w->user_data();
    app->audio_->setVoiceAmplitude(id, (float)((Fl_Value_Slider*)w)->value());
}

void HarmoniaApp::cbVoiceDetune(Fl_Widget* w, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    int id = (int)(intptr_t)w->user_data();
    app->audio_->setVoiceDetune(id, (float)((Fl_Value_Slider*)w)->value());
}

void HarmoniaApp::cbVoiceTimbre(Fl_Widget* w, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    int id = (int)(intptr_t)w->user_data();
    int t  = ((Fl_Choice*)w)->value();
    static const TimbrePreset PRESETS[] = {
        TimbrePreset::SINE, TimbrePreset::SAWTOOTH, TimbrePreset::SQUARE,
        TimbrePreset::STRINGS, TimbrePreset::BRASS, TimbrePreset::FLUTE
    };
    if (t >= 0 && t < 6) app->audio_->setVoiceTimbre(id, PRESETS[t]);
}

void HarmoniaApp::cbVoiceRemove(Fl_Widget* w, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    int id = (int)(intptr_t)w->user_data();
    app->removeVoice(id);
}

// ─────────────────────────────────────────────────────────────────────────────
int main(int argc, char** argv) {
    // Request FLTK lock for threaded use
    Fl::lock();

    HarmoniaApp app;
    app.run();
    return 0;
}
