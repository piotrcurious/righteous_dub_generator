#pragma once
#include <string>
#include <vector>
#include <functional>
#include <thread>
#include <mutex>
#include <atomic>
#include <deque>

// ────────────────────────────────────────────────────────────────────────────
//  THEORY BRIDGE — subprocess IPC with Python theory server.
//
//  Protocol: newline-delimited JSON over stdin/stdout.
//
//  Requests (→ Python):
//    {"cmd":"next_chords","current":{"root":0,"type":"maj"},"key":0,"n":5}
//    {"cmd":"ji_lattice","fifths":2,"thirds":-1}
//    {"cmd":"suggest_completion","pitch_classes":[0,7],"key":0}
//    {"cmd":"orbifold_distance","chord_a":[0,4,7],"chord_b":[0,3,7]}
//    {"cmd":"microtonal_scale","edo":31,"target_intervals":[[3,2],[5,4]]}
//
//  Responses (← Python):
//    {"result":"next_chords","chords":[{"root":7,"type":"maj","prob":0.35},...]}
//    {"result":"ji_lattice","ratio":"3/2","cents":701.955}
//    {"result":"suggest_completion","suggestions":[{"pitch_class":4,"label":"E"},...]}
// ────────────────────────────────────────────────────────────────────────────

struct ChordSuggestion {
    int   root_pc;        // 0-11
    std::string type;     // "maj","min","7","maj7", etc.
    float probability;    // Markov probability
    std::string label;    // "G7", "Cmaj", etc.
    // Tonnetz movement from current
    int   delta_fifths;
    int   delta_thirds;
};

struct NoteSuggestion {
    int   pitch_class;
    std::string name;     // "E", "G#", etc.
    float score;          // consonance score
    float roughness_delta; // change in roughness if added
    float cents_ji;       // JI tuning
};

struct OrbifoldDistance {
    float voice_leading_distance;  // semitones total motion
    std::vector<std::pair<int,int>> voice_motions;  // (from_pc, to_pc) per voice
};

class TheoryBridge {
public:
    TheoryBridge();
    ~TheoryBridge();

    // ── start Python subprocess
    bool start(const std::string& theory_dir);
    void stop();
    bool isRunning() const { return running_.load(); }

    // ── async queries (result delivered via callback on main thread)
    using ChordsCb    = std::function<void(const std::vector<ChordSuggestion>&)>;
    using NotesCb     = std::function<void(const std::vector<NoteSuggestion>&)>;
    using OrbifoldCb  = std::function<void(const OrbifoldDistance&)>;
    using RawJsonCb   = std::function<void(const std::string&)>;

    void queryNextChords(int current_root, const std::string& current_type,
                         int key_pc, int n, ChordsCb cb);
    void querySuggestCompletion(const std::vector<int>& pitch_classes,
                                int key_pc, NotesCb cb);
    void queryOrbifoldDistance(const std::vector<int>& chord_a,
                                const std::vector<int>& chord_b,
                                OrbifoldCb cb);
    void queryEDOAnalysis(int edo, RawJsonCb cb);

    // ── poll: call from UI idle handler to dispatch pending callbacks
    void poll();

    // ── synchronous fallback (blocks, ≤100ms)
    std::string sendSync(const std::string& json, int timeout_ms = 100);

private:
    pid_t py_pid_{-1};
    int   to_py_[2]{-1,-1};    // write end → Python stdin
    int   from_py_[2]{-1,-1};  // read end  ← Python stdout

    std::thread reader_thread_;
    std::atomic<bool> running_{false};

    // ── pending callbacks
    struct PendingCb {
        std::string result_tag;
        std::function<void(const std::string&)> raw_cb;
    };
    mutable std::mutex pending_mutex_;
    std::deque<PendingCb> pending_cbs_;

    // ── incoming responses
    mutable std::mutex response_mutex_;
    std::deque<std::string> responses_;

    void readerLoop();
    void sendRaw(const std::string& json);

    // ── JSON helpers (minimal, no external deps)
    static std::string jsonStr(const std::string& key, const std::string& val);
    static std::string jsonInt(const std::string& key, int val);
    static std::string jsonFloat(const std::string& key, float val);
    static std::string jsonIntArr(const std::string& key, const std::vector<int>& arr);
    static int    extractInt(const std::string& json, const std::string& key, int def=0);
    static float  extractFloat(const std::string& json, const std::string& key, float def=0.f);
    static std::string extractString(const std::string& json, const std::string& key, const std::string& def="");
};
