/*
 * harmonia/src/main.cpp
 * ─────────────────────────────────────────────────────────────────────────────
 *  HARMONIA — Multi-voice psychoacoustic music coder
 *
 *  Window layout (1280 × 820):
 *  ┌──────────────────────────────────────────────────────────────────────────┐
 *  │  [Harmonia]  Key: C▼  EDO: 12▼  Master:━━━━  [Add Voice] [Play All]    │ ← toolbar
 *  ├─────────────────┬────────────────────────────┬───────────────────────────┤
 *  │                 │                            │                           │
 *  │   VOICE LIST    │      TONNETZ (OpenGL)      │   THEORY PANEL            │
 *  │   + controls    │                            │   • Next chords           │
 *  │                 │  Interactive harmonic       │   • Completion            │
 *  │  [voice strip]  │  lattice. Click=add note   │   • Orbifold dist         │
 *  │  [voice strip]  │  Middle-drag=pan           │   • EDO analysis          │
 *  │  ...            │  Scroll=zoom               │                           │
 *  │                 │                            │                           │
 *  ├─────────────────┴────────────────────────────┴───────────────────────────┤
 *  │  SPECTRUM + ROUGHNESS bar            OBJECT DISPLAY                      │ ← status
 *  └──────────────────────────────────────────────────────────────────────────┘
 */

#include <FL/Fl.H>
#include <FL/Fl_Double_Window.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Choice.H>
#include <FL/Fl_Value_Slider.H>
#include <FL/Fl_Scroll.H>
#include <FL/Fl_Output.H>
#include <FL/Fl_Input.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Light_Button.H>
#include <FL/Fl_Browser.H>
#include <FL/Fl_Spinner.H>
#include <FL/fl_draw.H>
#include <FL/Fl_Gl_Window.H>
#include <GL/gl.h>
#include <vector>
#include <string>
#include <sstream>
#include <memory>
#include <functional>
#include <map>
#include <cmath>
#include <cstdio>

#include "voice.h"
#include "audio_engine.h"
#include "tonnetz_widget.h"
#include "theory_bridge.h"

// ─────────────────────────────────────────────────────────────────────────────
//  FLTK colour helpers
// ─────────────────────────────────────────────────────────────────────────────
static Fl_Color flColor(float r, float g, float b) {
    return fl_rgb_color((uchar)(r*255),(uchar)(g*255),(uchar)(b*255));
}
static const Fl_Color COL_BG     = fl_rgb_color(18,20,28);
static const Fl_Color COL_PANEL  = fl_rgb_color(26,30,40);
static const Fl_Color COL_ACCENT = fl_rgb_color(200,160,40);
static const Fl_Color COL_TEXT   = fl_rgb_color(220,215,200);
static const Fl_Color COL_DIM    = fl_rgb_color(100,100,110);

// ─────────────────────────────────────────────────────────────────────────────
//  SPECTRUM DISPLAY — OpenGL widget showing partials per voice
// ─────────────────────────────────────────────────────────────────────────────
class SpectrumWidget : public Fl_Gl_Window {
public:
    SpectrumWidget(int X,int Y,int W,int H)
        : Fl_Gl_Window(X,Y,W,H)
    { mode(FL_RGB|FL_DOUBLE); }

    void update(const SpectrumSnapshot& snap, const std::vector<Voice>& voices,
                float roughness) {
        snap_ = snap; voices_ = voices; roughness_ = roughness; redraw();
    }

    void draw() override {
        if (!valid()) {
            glViewport(0,0,w(),h());
            glMatrixMode(GL_PROJECTION); glLoadIdentity();
            glOrtho(0,w(),h(),0,-1,1);
            glMatrixMode(GL_MODELVIEW); glLoadIdentity();
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
        }
        glClearColor(0.07f,0.08f,0.11f,1.f);
        glClear(GL_COLOR_BUFFER_BIT);

        // Draw spectrum bars
        int sw = w(), sh = h()-20;
        float bin_w = (float)sw / (SPECTRUM_SIZE/2);
        for (int i = 0; i < SPECTRUM_SIZE/2; i++) {
            float mag = snap_.magnitude[i];
            if (mag < 1e-5f) continue;
            float bh = std::min((float)sh, mag * sh * 3.f);
            // color by frequency
            float t = (float)i / (SPECTRUM_SIZE/2);
            float r = 0.2f + 0.8f*t, g = 0.7f - 0.5f*t, b = 1.f - 0.7f*t;
            glColor4f(r,g,b, 0.85f);
            glBegin(GL_QUADS);
            glVertex2f(i*bin_w, sh);
            glVertex2f((i+1)*bin_w, sh);
            glVertex2f((i+1)*bin_w, sh-bh);
            glVertex2f(i*bin_w, sh-bh);
            glEnd();
        }

        // Roughness bar at bottom
        float rw = roughness_ * sw;
        float rg = 1.f - roughness_;
        glColor4f(roughness_, rg, 0.f, 0.8f);
        glBegin(GL_QUADS);
        glVertex2f(0,sh); glVertex2f(rw,sh);
        glVertex2f(rw,h()); glVertex2f(0,h());
        glEnd();

        gl_font(FL_HELVETICA, 9);
        glColor3f(.6f,.6f,.6f);
        gl_draw("Roughness", 2, h()-3);
        char rbuf[32]; snprintf(rbuf,sizeof(rbuf),"%.2f", roughness_);
        gl_draw(rbuf, (int)(rw + 4), h()-3);

        // Freq axis labels
        glColor3f(.4f,.4f,.5f);
        static const int FREQ_MARKS[] = {100,200,500,1000,2000,4000,8000,0};
        for (int i = 0; FREQ_MARKS[i]; i++) {
            float f = FREQ_MARKS[i];
            float x = (f / (SAMPLE_RATE/2)) * sw;
            glBegin(GL_LINES); glVertex2f(x,sh); glVertex2f(x,sh-4); glEnd();
            char lbl[16]; snprintf(lbl,sizeof(lbl),"%d",FREQ_MARKS[i]);
            gl_draw(lbl, (int)x-8, sh-6);
        }
    }

private:
    SpectrumSnapshot snap_;
    std::vector<Voice> voices_;
    float roughness_{0.f};
};

// ─────────────────────────────────────────────────────────────────────────────
//  VOICE STRIP — one row per voice in the left panel
// ─────────────────────────────────────────────────────────────────────────────
struct VoiceStrip {
    int voice_id{-1};
    Fl_Group*       group{nullptr};
    Fl_Light_Button* btn_on{nullptr};
    Fl_Box*          lbl_note{nullptr};
    Fl_Value_Slider* sl_amp{nullptr};
    Fl_Value_Slider* sl_detune{nullptr};
    Fl_Choice*       ch_timbre{nullptr};
    Fl_Button*       btn_remove{nullptr};
    Fl_Box*          roughness_box{nullptr};
    float            roughness_val{0.f};
    float            color[3]{0.5f,0.7f,1.f};
};

// ─────────────────────────────────────────────────────────────────────────────
//  MAIN WINDOW
// ─────────────────────────────────────────────────────────────────────────────
class HarmoniaApp {
public:
    HarmoniaApp();
    ~HarmoniaApp();
    void run();

private:
    static constexpr int WIN_W = 1280, WIN_H = 820;
    static constexpr int TOOLBAR_H = 38;
    static constexpr int VOICE_PANEL_W = 260;
    static constexpr int THEORY_PANEL_W = 300;
    static constexpr int STATUS_H = 120;
    static constexpr int TONNETZ_W = WIN_W - VOICE_PANEL_W - THEORY_PANEL_W;
    static constexpr int TONNETZ_H = WIN_H - TOOLBAR_H - STATUS_H;

    // ── FLTK widgets
    Fl_Double_Window* win_{nullptr};

    // Toolbar
    Fl_Button*       btn_add_{nullptr};
    Fl_Button*       btn_play_all_{nullptr};
    Fl_Button*       btn_stop_all_{nullptr};
    Fl_Choice*       ch_key_{nullptr};
    Fl_Spinner*      sp_edo_{nullptr};
    Fl_Value_Slider* sl_master_{nullptr};
    Fl_Output*       out_object_{nullptr};

    // Left panel – voice list
    Fl_Scroll*        scroll_voices_{nullptr};
    std::vector<VoiceStrip*> strips_;
    int               voice_panel_y_{0};  // next y for new strip

    // Centre – Tonnetz
    TonnetzWidget*    tonnetz_{nullptr};

    // Right – theory panel
    Fl_Browser*       browser_chords_{nullptr};
    Fl_Browser*       browser_completion_{nullptr};
    Fl_Browser*       browser_edo_{nullptr};
    Fl_Button*        btn_suggest_{nullptr};
    Fl_Button*        btn_edo_{nullptr};
    Fl_Output*        out_orbifold_{nullptr};

    // Bottom – spectrum + roughness
    SpectrumWidget*   spectrum_{nullptr};
    Fl_Box*           box_object_label_{nullptr};

    // ── engines
    std::unique_ptr<AudioEngine>  audio_;
    std::unique_ptr<TheoryBridge> theory_;

    // ── state
    int  current_key_{0};     // 0=C
    int  current_edo_{12};
    int  last_clicked_root_{-1};
    std::string last_chord_type_{"maj"};
    std::vector<int> last_suggested_pcs_;
    std::vector<ChordSuggestion> last_chord_suggestions_;

    // ── methods
    void buildUI();
    void setupCallbacks();

    // Voice management
    void addVoice(int midi_note = 60, TimbrePreset t = TimbrePreset::STRINGS);
    void removeVoice(int voice_id);
    void refreshStrip(VoiceStrip* strip);
    VoiceStrip* findStrip(int voice_id);
    void relayoutStrips();

    // Theory panel updates
    void updateChordSuggestions(int root_pc, const std::string& type);
    void updateCompletionSuggestions();
    void updateEDOAnalysis();
    void updateOrbifoldDisplay(const std::vector<int>& chord_a,
                                const std::vector<int>& chord_b);

    // Idle/timer callbacks (static for FLTK)
    static void onIdle(void* data);
    static void onTimer(void* data);

    // Widget callbacks
    static void cbAddVoice(Fl_Widget*, void* d)    { ((HarmoniaApp*)d)->addVoice(); }
    static void cbPlayAll(Fl_Widget*, void* d);
    static void cbStopAll(Fl_Widget*, void* d);
    static void cbMasterVol(Fl_Widget*, void* d);
    static void cbKey(Fl_Widget*, void* d);
    static void cbEDO(Fl_Widget*, void* d);
    static void cbSuggestChords(Fl_Widget*, void* d);
    static void cbSuggestCompletion(Fl_Widget*, void* d);
    static void cbAnalyseEDO(Fl_Widget*, void* d);

    // Voice strip callbacks
    static void cbVoiceOn(Fl_Widget* w, void* d);
    static void cbVoiceAmp(Fl_Widget* w, void* d);
    static void cbVoiceDetune(Fl_Widget* w, void* d);
    static void cbVoiceTimbre(Fl_Widget* w, void* d);
    static void cbVoiceRemove(Fl_Widget* w, void* d);

    // Tonnetz click
    void onTonnetzClick(int pitch_class, int tx, int ty);

    std::string theoryDir_;
};

// ─────────────────────────────────────────────────────────────────────────────
HarmoniaApp::HarmoniaApp() {
    audio_  = std::make_unique<AudioEngine>();
    theory_ = std::make_unique<TheoryBridge>();
    buildUI();
    setupCallbacks();
}

HarmoniaApp::~HarmoniaApp() {
    audio_->shutdown();
    theory_->stop();
}

void HarmoniaApp::run() {
    // ── start audio (ALSA)
    if (!audio_->init()) {
        fl_message("ALSA init failed — audio disabled");
    }

    // ── find theory server
    char exepath[512] = {};
    ssize_t n = readlink("/proc/self/exe", exepath, sizeof(exepath)-1);
    if (n > 0) {
        std::string dir(exepath, n);
        size_t pos = dir.rfind('/');
        theoryDir_ = dir.substr(0, pos) + "/../theory";
    } else {
        theoryDir_ = "./theory";
    }

    if (!theory_->start(theoryDir_)) {
        fl_message("Python theory server not started — theory features disabled");
    }

    // ── seed with a C major chord
    addVoice(60, TimbrePreset::STRINGS);  // C4
    addVoice(64, TimbrePreset::STRINGS);  // E4
    addVoice(67, TimbrePreset::STRINGS);  // G4

    // ── play them
    for (auto& s : strips_) audio_->noteOn(s->voice_id);

    // ── initial theory query
    updateChordSuggestions(0, "maj");

    Fl::add_idle(onIdle, this);
    Fl::run();
}

// ─────────────────────────────────────────────────────────────────────────────
//  UI CONSTRUCTION
// ─────────────────────────────────────────────────────────────────────────────
void HarmoniaApp::buildUI() {
    Fl::scheme("gtk+");
    Fl::background(18,20,28);
    Fl::foreground(220,215,200);

    win_ = new Fl_Double_Window(WIN_W, WIN_H, "Harmonia — Psychoacoustic Music Coder");
    win_->color(COL_BG);

    // ── TOOLBAR ──────────────────────────────────────────────────────────────
    {
        Fl_Group* tb = new Fl_Group(0, 0, WIN_W, TOOLBAR_H);
        tb->box(FL_FLAT_BOX); tb->color(fl_rgb_color(14,16,22));

        int x = 8, y = 6, bh = 26;

        Fl_Box* title = new Fl_Box(x,y,100,bh,"HARMONIA");
        title->labelcolor(COL_ACCENT); title->labelfont(FL_HELVETICA_BOLD);
        title->labelsize(14); title->box(FL_NO_BOX);
        x += 108;

        new Fl_Box(x,y,30,bh,"Key:"); x+=30;
        ch_key_ = new Fl_Choice(x,y,70,bh);
        for (int i=0;i<12;i++) ch_key_->add(NOTE_NAMES[i]);
        ch_key_->value(0); x += 76;

        new Fl_Box(x,y,30,bh,"EDO:"); x+=32;
        sp_edo_ = new Fl_Spinner(x,y,60,bh);
        sp_edo_->minimum(5); sp_edo_->maximum(72); sp_edo_->value(12);
        x += 68;

        new Fl_Box(x,y,50,bh,"Master:"); x+=52;
        sl_master_ = new Fl_Value_Slider(x,y,100,bh);
        sl_master_->type(FL_HORIZONTAL); sl_master_->minimum(0); sl_master_->maximum(1);
        sl_master_->value(0.5); sl_master_->color(fl_rgb_color(40,44,58));
        x += 110;

        btn_add_ = new Fl_Button(x,y,90,bh,"+ Add Voice");
        btn_add_->color(fl_rgb_color(30,80,50)); btn_add_->labelcolor(fl_rgb_color(120,220,100));
        x += 98;

        btn_play_all_ = new Fl_Button(x,y,70,bh,"▶ All");
        btn_play_all_->color(fl_rgb_color(30,60,100)); btn_play_all_->labelcolor(fl_rgb_color(100,180,255));
        x += 76;

        btn_stop_all_ = new Fl_Button(x,y,70,bh,"■ Stop");
        btn_stop_all_->color(fl_rgb_color(80,30,30)); btn_stop_all_->labelcolor(fl_rgb_color(255,120,100));
        x += 76;

        out_object_ = new Fl_Output(x,y, WIN_W-x-8, bh);
        out_object_->box(FL_FLAT_BOX); out_object_->color(fl_rgb_color(20,24,32));
        out_object_->textcolor(COL_ACCENT); out_object_->textsize(13);
        out_object_->value("Object: —");

        tb->end();
    }

    int content_y = TOOLBAR_H;
    int content_h = WIN_H - TOOLBAR_H - STATUS_H;

    // ── VOICE PANEL (left) ────────────────────────────────────────────────────
    {
        Fl_Group* panel = new Fl_Group(0, content_y, VOICE_PANEL_W, content_h);
        panel->box(FL_FLAT_BOX); panel->color(fl_rgb_color(22,26,35));

        Fl_Box* hdr = new Fl_Box(0,content_y, VOICE_PANEL_W,22,"VOICES");
        hdr->box(FL_FLAT_BOX); hdr->color(fl_rgb_color(30,34,46));
        hdr->labelcolor(COL_DIM); hdr->labelfont(FL_HELVETICA); hdr->labelsize(10);

        scroll_voices_ = new Fl_Scroll(0, content_y+22, VOICE_PANEL_W, content_h-22);
        scroll_voices_->box(FL_FLAT_BOX); scroll_voices_->color(fl_rgb_color(22,26,35));
        scroll_voices_->type(Fl_Scroll::VERTICAL_ALWAYS);
        scroll_voices_->end();

        voice_panel_y_ = content_y + 22;
        panel->end();
    }

    // ── TONNETZ (centre) ──────────────────────────────────────────────────────
    {
        tonnetz_ = new TonnetzWidget(VOICE_PANEL_W, content_y, TONNETZ_W, content_h);
    }

    // ── THEORY PANEL (right) ─────────────────────────────────────────────────
    {
        int tx = VOICE_PANEL_W + TONNETZ_W;
        Fl_Group* panel = new Fl_Group(tx, content_y, THEORY_PANEL_W, content_h);
        panel->box(FL_FLAT_BOX); panel->color(fl_rgb_color(22,26,35));

        int py = content_y+4, pw = THEORY_PANEL_W-8, px = tx+4;

        // ─ Next Chords
        Fl_Box* h1 = new Fl_Box(px,py,pw,18,"Next Chords (Markov)");
        h1->labelfont(FL_HELVETICA); h1->labelsize(10); h1->labelcolor(COL_ACCENT);
        h1->box(FL_NO_BOX); py+=20;

        browser_chords_ = new Fl_Browser(px,py,pw,110);
        browser_chords_->textsize(11); browser_chords_->color(fl_rgb_color(18,22,30));
        browser_chords_->textcolor(COL_TEXT); py+=114;

        btn_suggest_ = new Fl_Button(px,py,pw,22,"Suggest from current chord");
        btn_suggest_->labelsize(10); btn_suggest_->color(fl_rgb_color(30,50,80));
        py += 26;

        // ─ Completion
        Fl_Box* h2 = new Fl_Box(px,py,pw,18,"Voice Completion");
        h2->labelfont(FL_HELVETICA); h2->labelsize(10); h2->labelcolor(COL_ACCENT);
        h2->box(FL_NO_BOX); py+=20;

        browser_completion_ = new Fl_Browser(px,py,pw,120);
        browser_completion_->textsize(10); browser_completion_->color(fl_rgb_color(18,22,30));
        browser_completion_->textcolor(COL_TEXT); py+=124;

        Fl_Button* btn_comp = new Fl_Button(px,py,pw,22,"Suggest completion note");
        btn_comp->labelsize(10); btn_comp->color(fl_rgb_color(30,50,80));
        btn_comp->callback(cbSuggestCompletion, this); py += 26;

        // ─ Orbifold distance
        Fl_Box* h3 = new Fl_Box(px,py,pw,18,"Orbifold / Voice-leading");
        h3->labelfont(FL_HELVETICA); h3->labelsize(10); h3->labelcolor(COL_ACCENT);
        h3->box(FL_NO_BOX); py+=20;

        out_orbifold_ = new Fl_Output(px,py,pw,42);
        out_orbifold_->textsize(10); out_orbifold_->color(fl_rgb_color(18,22,30));
        out_orbifold_->textcolor(fl_rgb_color(150,200,150)); py+=46;

        // ─ EDO analysis
        Fl_Box* h4 = new Fl_Box(px,py,pw,18,"EDO Analysis");
        h4->labelfont(FL_HELVETICA); h4->labelsize(10); h4->labelcolor(COL_ACCENT);
        h4->box(FL_NO_BOX); py+=20;

        browser_edo_ = new Fl_Browser(px,py,pw, content_h - (py - content_y) - 28);
        browser_edo_->textsize(9); browser_edo_->color(fl_rgb_color(18,22,30));
        browser_edo_->textcolor(COL_TEXT);
        py = content_y + content_h - 26;

        btn_edo_ = new Fl_Button(px,py,pw,22,"Analyse current EDO");
        btn_edo_->labelsize(10); btn_edo_->color(fl_rgb_color(50,30,80));
        btn_edo_->callback(cbAnalyseEDO, this);

        panel->end();
    }

    // ── STATUS / SPECTRUM BAR (bottom) ────────────────────────────────────────
    {
        int sy = WIN_H - STATUS_H;
        Fl_Group* sb = new Fl_Group(0,sy, WIN_W, STATUS_H);
        sb->box(FL_FLAT_BOX); sb->color(fl_rgb_color(14,16,22));

        spectrum_ = new SpectrumWidget(0, sy, WIN_W - 250, STATUS_H);

        box_object_label_ = new Fl_Box(WIN_W-248, sy, 248, STATUS_H, "");
        box_object_label_->box(FL_FLAT_BOX); box_object_label_->color(fl_rgb_color(18,22,30));
        box_object_label_->labelcolor(COL_ACCENT); box_object_label_->labelfont(FL_HELVETICA_BOLD);
        box_object_label_->labelsize(16); box_object_label_->align(FL_ALIGN_CENTER|FL_ALIGN_INSIDE);

        sb->end();
    }

    win_->end();
    win_->show();
}

// ─────────────────────────────────────────────────────────────────────────────
void HarmoniaApp::setupCallbacks() {
    btn_add_->callback(cbAddVoice, this);
    btn_play_all_->callback(cbPlayAll, this);
    btn_stop_all_->callback(cbStopAll, this);
    sl_master_->callback(cbMasterVol, this);
    ch_key_->callback(cbKey, this);
    sp_edo_->callback(cbEDO, this);
    btn_suggest_->callback(cbSuggestChords, this);

    tonnetz_->setNodeClickCallback([this](int pc, int tx, int ty){
        onTonnetzClick(pc, tx, ty);
    });

    audio_->setRoughnessCallback([this](const std::vector<RoughnessRecord>& rr,
                                         const AbstractObject& obj) {
        // This runs on audio thread — just store, pick up in idle
        // (AbstractObject is already stored inside AudioEngine)
    });
}

// ─────────────────────────────────────────────────────────────────────────────
//  VOICE MANAGEMENT
// ─────────────────────────────────────────────────────────────────────────────
void HarmoniaApp::addVoice(int midi_note, TimbrePreset t) {
    int id = audio_->addVoice(midi_note, t);
    if (id < 0) { fl_message("Max voices reached"); return; }

    static const int STRIP_H = 72;
    int sw = VOICE_PANEL_W - 12;

    // Compute y inside scroll
    int yrel = 0;
    for (auto& s : strips_) yrel += STRIP_H + 2;

    scroll_voices_->begin();
    VoiceStrip* strip = new VoiceStrip();
    strip->voice_id = id;

    int gx = 4, gy = scroll_voices_->y() + yrel + 2;
    strip->group = new Fl_Group(gx, gy, sw, STRIP_H);
    strip->group->box(FL_FLAT_BOX);
    strip->group->color(fl_rgb_color(28,32,44));

    // Note label
    strip->lbl_note = new Fl_Box(gx+2, gy+2, 52, 20, "—");
    strip->lbl_note->box(FL_FLAT_BOX);
    strip->lbl_note->color(fl_rgb_color(14,16,22));
    strip->lbl_note->labelcolor(COL_TEXT);
    strip->lbl_note->labelfont(FL_HELVETICA_BOLD);
    strip->lbl_note->labelsize(13);

    // On/Off
    strip->btn_on = new Fl_Light_Button(gx+58, gy+2, 44, 20, "ON");
    strip->btn_on->labelsize(10);
    strip->btn_on->value(0);
    strip->btn_on->user_data((void*)(intptr_t)id);
    strip->btn_on->callback(cbVoiceOn, this);

    // Remove
    strip->btn_remove = new Fl_Button(gx+sw-26, gy+2, 22, 20, "×");
    strip->btn_remove->labelsize(13);
    strip->btn_remove->color(fl_rgb_color(80,24,24));
    strip->btn_remove->labelcolor(fl_rgb_color(255,100,100));
    strip->btn_remove->user_data((void*)(intptr_t)id);
    strip->btn_remove->callback(cbVoiceRemove, this);

    // Amplitude slider
    new Fl_Box(gx+2, gy+24, 30, 14, "Amp");
    ((Fl_Box*)Fl::focus())->labelsize(9);
    strip->sl_amp = new Fl_Value_Slider(gx+34, gy+24, sw-60, 14);
    strip->sl_amp->type(FL_HORIZONTAL); strip->sl_amp->minimum(0); strip->sl_amp->maximum(1);
    strip->sl_amp->value(0.6); strip->sl_amp->textsize(8);
    strip->sl_amp->user_data((void*)(intptr_t)id);
    strip->sl_amp->callback(cbVoiceAmp, this);

    // Detune slider
    new Fl_Box(gx+2, gy+40, 30, 14, "Det");
    strip->sl_detune = new Fl_Value_Slider(gx+34, gy+40, sw-60, 14);
    strip->sl_detune->type(FL_HORIZONTAL); strip->sl_detune->minimum(-50); strip->sl_detune->maximum(50);
    strip->sl_detune->value(0); strip->sl_detune->textsize(8);
    strip->sl_detune->user_data((void*)(intptr_t)id);
    strip->sl_detune->callback(cbVoiceDetune, this);

    // Timbre choice
    strip->ch_timbre = new Fl_Choice(gx+2, gy+56, sw-4, 14);
    strip->ch_timbre->textsize(9);
    strip->ch_timbre->add("Sine|Sawtooth|Square|Strings|Brass|Flute");
    strip->ch_timbre->value(3);  // Strings
    strip->ch_timbre->user_data((void*)(intptr_t)id);
    strip->ch_timbre->callback(cbVoiceTimbre, this);

    // Roughness indicator box
    strip->roughness_box = new Fl_Box(gx+104, gy+2, 50, 20, "");
    strip->roughness_box->box(FL_FLAT_BOX);
    strip->roughness_box->color(fl_rgb_color(14,16,22));
    strip->roughness_box->labelcolor(COL_TEXT); strip->roughness_box->labelsize(9);

    strip->group->end();
    scroll_voices_->end();

    // Update note label
    auto voices = audio_->getVoiceSnapshot();
    for (auto& v : voices) {
        if (v.id == id) {
            strip->color[0] = v.color[0]; strip->color[1] = v.color[1]; strip->color[2] = v.color[2];
            char buf[16];
            snprintf(buf,sizeof(buf),"%s%d", NOTE_NAMES[v.pitch_class], v.octave);
            strip->lbl_note->label(buf);
            strip->lbl_note->copy_label(buf);
            strip->group->color(flColor(v.color[0]*0.15f, v.color[1]*0.15f, v.color[2]*0.15f));
        }
    }

    strips_.push_back(strip);
    scroll_voices_->redraw();
    win_->redraw();
}

void HarmoniaApp::removeVoice(int voice_id) {
    audio_->noteOff(voice_id);
    audio_->removeVoice(voice_id);

    auto it = std::find_if(strips_.begin(), strips_.end(),
        [voice_id](VoiceStrip* s){ return s->voice_id == voice_id; });
    if (it != strips_.end()) {
        scroll_voices_->remove((*it)->group);
        Fl::delete_widget((*it)->group);
        delete *it;
        strips_.erase(it);
    }
    relayoutStrips();
    scroll_voices_->redraw();
}

void HarmoniaApp::relayoutStrips() {
    static const int STRIP_H = 72;
    int y = scroll_voices_->y() + 2;
    for (auto* s : strips_) {
        int dy = y - s->group->y();
        s->group->position(s->group->x(), y);
        y += STRIP_H + 2;
    }
}

VoiceStrip* HarmoniaApp::findStrip(int voice_id) {
    for (auto* s : strips_) if (s->voice_id == voice_id) return s;
    return nullptr;
}

// ─────────────────────────────────────────────────────────────────────────────
//  IDLE — update UI from audio thread results
// ─────────────────────────────────────────────────────────────────────────────
void HarmoniaApp::onIdle(void* data) {
    HarmoniaApp* app = (HarmoniaApp*)data;

    // ── poll theory bridge callbacks
    app->theory_->poll();

    // ── update spectrum
    auto snap   = app->audio_->getSpectrumSnapshot();
    auto voices = app->audio_->getVoiceSnapshot();
    auto rr     = app->audio_->getRoughnessSnapshot();
    auto obj    = app->audio_->getAbstractObject();

    // Total roughness for spectrum display
    float total_rough = 0.f;
    for (auto& r : rr) total_rough += r.roughness;
    app->spectrum_->update(snap, voices, std::min(1.f, total_rough));

    // ── Update Tonnetz
    app->tonnetz_->setVoices(voices);
    app->tonnetz_->setAbstractObject(obj);
    app->tonnetz_->setRoughnessRecords(rr);

    // ── Update object display
    if (obj.confidence > 0.2f) {
        char buf[128];
        snprintf(buf,sizeof(buf), "%s  [vp=%.0fHz]  conf=%.0f%%  R=%.2f",
                 obj.chord_name.c_str(), obj.virtual_pitch_hz,
                 obj.confidence * 100.f, obj.roughness_total);
        app->out_object_->value(buf);
        app->box_object_label_->copy_label(obj.chord_name.c_str());
    }

    // ── Update roughness on each voice strip
    std::map<int,float> voice_rough;
    for (auto& r : rr) {
        voice_rough[r.voice_a] += r.roughness;
        voice_rough[r.voice_b] += r.roughness;
    }
    for (auto* s : app->strips_) {
        float rv = voice_rough.count(s->voice_id) ? voice_rough[s->voice_id] : 0.f;
        s->roughness_val = rv;
        char rbuf[16]; snprintf(rbuf,sizeof(rbuf),"R:%.2f",rv);
        s->roughness_box->copy_label(rbuf);
        // color roughness box
        float rn = std::min(1.f, rv);
        s->roughness_box->color(fl_rgb_color((uchar)(rn*200),(uchar)((1-rn)*160),40));
        s->roughness_box->redraw();
    }

    Fl::check();
}

// ─────────────────────────────────────────────────────────────────────────────
//  TONNETZ CLICK — add voice at clicked pitch class
// ─────────────────────────────────────────────────────────────────────────────
void HarmoniaApp::onTonnetzClick(int pitch_class, int tx, int ty) {
    // Find MIDI note: closest to middle C (60) with correct pitch class
    int midi = 60 + ((pitch_class - 60%12 + 12) % 12);
    if (midi < 48) midi += 12;
    if (midi > 84) midi -= 12;

    last_clicked_root_ = pitch_class;
    auto voices = audio_->getVoiceSnapshot();

    // If already have this PC, remove it; else add it
    bool found = false;
    for (auto& v : voices) {
        if (v.active && v.pitch_class == pitch_class) {
            audio_->noteOff(v.id); found = true; break;
        }
    }
    if (!found) {
        addVoice(midi);
        // auto-play
        if (!strips_.empty()) {
            int newid = strips_.back()->voice_id;
            audio_->noteOn(newid);
            if (auto* s = findStrip(newid)) s->btn_on->value(1);
        }
    }

    // ── update theory
    auto obj = audio_->getAbstractObject();
    updateChordSuggestions(pitch_class, "maj");
    updateCompletionSuggestions();
}

// ─────────────────────────────────────────────────────────────────────────────
//  THEORY PANEL UPDATES
// ─────────────────────────────────────────────────────────────────────────────
void HarmoniaApp::updateChordSuggestions(int root, const std::string& type) {
    last_chord_type_ = type;
    theory_->queryNextChords(root, type, current_key_, 8,
        [this](const std::vector<ChordSuggestion>& cs) {
            last_chord_suggestions_ = cs;
            browser_chords_->clear();
            for (auto& c : cs) {
                char buf[128];
                snprintf(buf,sizeof(buf),"  %-8s  %s  %.0f%%  [%+d,%+d]",
                         c.label.c_str(), c.roman.empty()?"":c.roman.c_str(),
                         c.probability*100.f, c.delta_fifths, c.delta_thirds);
                browser_chords_->add(buf);
            }
            browser_chords_->redraw();
        });
}

void HarmoniaApp::updateCompletionSuggestions() {
    auto voices = audio_->getVoiceSnapshot();
    std::vector<int> pcs;
    for (auto& v : voices) if (v.active) pcs.push_back(v.pitch_class);

    theory_->querySuggestCompletion(pcs, current_key_,
        [this](const std::vector<NoteSuggestion>& ns) {
            browser_completion_->clear();
            for (auto& n : ns) {
                char buf[128];
                snprintf(buf,sizeof(buf),"  %-3s  score=%.2f  ΔR=%+.2f  JI=%.1f¢  %s",
                         n.name.c_str(), n.score, n.roughness_delta,
                         n.cents_ji, n.harmonic_function.empty()?"":n.harmonic_function.c_str());
                browser_completion_->add(buf);
            }
            browser_completion_->redraw();
        });
}

void HarmoniaApp::updateEDOAnalysis() {
    theory_->queryEDOAnalysis(current_edo_,
        [this](const std::string& raw) {
            browser_edo_->clear();
            // parse and display
            // Simple: look for "intervals" array entries
            browser_edo_->add(("  EDO-" + std::to_string(current_edo_)).c_str());
            // Extract consonance scores
            auto extract = [&](const std::string& key) {
                size_t p = raw.find("\"" + key + "\"");
                if (p==std::string::npos) return std::string("?");
                p = raw.find_first_of("0123456789.", p+key.size()+2);
                if (p==std::string::npos) return std::string("?");
                size_t e = raw.find_first_not_of("0123456789.", p);
                return raw.substr(p, e-p);
            };
            browser_edo_->add(("  5-limit score: " + extract("consonance_score")).c_str());
            browser_edo_->add(("  7-limit score: " + extract("seven_limit_score")).c_str());
            browser_edo_->add(("  Step: " + extract("step_cents") + "¢").c_str());
            // Interval table
            browser_edo_->add("  — Interval errors —");
            static const char* NAMES[] = {"fifth","major_third","minor_third",
                                           "harmonic_7th","11th_harm",nullptr};
            for (int i=0; NAMES[i]; i++) {
                size_t p = raw.find(NAMES[i]);
                if (p==std::string::npos) continue;
                size_t ep = raw.find("error_cents", p);
                if (ep==std::string::npos) continue;
                ep = raw.find_first_of("0123456789-.", ep+11);
                if (ep==std::string::npos) continue;
                size_t ee = raw.find_first_not_of("0123456789-.", ep);
                std::string err = raw.substr(ep, ee-ep);
                char buf[64];
                snprintf(buf,sizeof(buf),"  %-14s %s¢", NAMES[i], err.c_str());
                browser_edo_->add(buf);
            }
            browser_edo_->redraw();
        });
}

void HarmoniaApp::updateOrbifoldDisplay(const std::vector<int>& a, const std::vector<int>& b) {
    theory_->queryOrbifoldDistance(a, b,
        [this](const OrbifoldDistance& od) {
            char buf[128];
            snprintf(buf,sizeof(buf),"Voice-leading dist: %.0f semitones\n%s",
                     od.voice_leading_distance,
                     od.voice_leading_distance <= 3 ? "✓ Smooth (≤3)" :
                     od.voice_leading_distance <= 6 ? "~ Moderate" : "! Disjunct");
            out_orbifold_->value(buf);
        });
}

// ─────────────────────────────────────────────────────────────────────────────
//  STATIC CALLBACKS
// ─────────────────────────────────────────────────────────────────────────────
void HarmoniaApp::cbPlayAll(Fl_Widget*, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    for (auto* s : app->strips_) {
        app->audio_->noteOn(s->voice_id);
        s->btn_on->value(1);
    }
}

void HarmoniaApp::cbStopAll(Fl_Widget*, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    for (auto* s : app->strips_) {
        app->audio_->noteOff(s->voice_id);
        s->btn_on->value(0);
    }
}

void HarmoniaApp::cbMasterVol(Fl_Widget* w, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    app->audio_->setMasterVolume((float)((Fl_Value_Slider*)w)->value());
}

void HarmoniaApp::cbKey(Fl_Widget*, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    app->current_key_ = app->ch_key_->value();
}

void HarmoniaApp::cbEDO(Fl_Widget*, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    app->current_edo_ = (int)app->sp_edo_->value();
}

void HarmoniaApp::cbSuggestChords(Fl_Widget*, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    auto obj = app->audio_->getAbstractObject();
    app->updateChordSuggestions(obj.root_pc, "maj");
}

void HarmoniaApp::cbSuggestCompletion(Fl_Widget*, void* d) {
    ((HarmoniaApp*)d)->updateCompletionSuggestions();
}

void HarmoniaApp::cbAnalyseEDO(Fl_Widget*, void* d) {
    ((HarmoniaApp*)d)->updateEDOAnalysis();
}

void HarmoniaApp::cbVoiceOn(Fl_Widget* w, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    int id = (int)(intptr_t)w->user_data();
    Fl_Light_Button* btn = (Fl_Light_Button*)w;
    if (btn->value()) app->audio_->noteOn(id);
    else              app->audio_->noteOff(id);
}

void HarmoniaApp::cbVoiceAmp(Fl_Widget* w, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    int id = (int)(intptr_t)w->user_data();
    app->audio_->setVoiceAmplitude(id, (float)((Fl_Value_Slider*)w)->value());
}

void HarmoniaApp::cbVoiceDetune(Fl_Widget* w, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    int id = (int)(intptr_t)w->user_data();
    app->audio_->setVoiceDetune(id, (float)((Fl_Value_Slider*)w)->value());
}

void HarmoniaApp::cbVoiceTimbre(Fl_Widget* w, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    int id = (int)(intptr_t)w->user_data();
    int t  = ((Fl_Choice*)w)->value();
    static const TimbrePreset PRESETS[] = {
        TimbrePreset::SINE, TimbrePreset::SAWTOOTH, TimbrePreset::SQUARE,
        TimbrePreset::STRINGS, TimbrePreset::BRASS, TimbrePreset::FLUTE
    };
    if (t >= 0 && t < 6) app->audio_->setVoiceTimbre(id, PRESETS[t]);
}

void HarmoniaApp::cbVoiceRemove(Fl_Widget* w, void* d) {
    HarmoniaApp* app = (HarmoniaApp*)d;
    int id = (int)(intptr_t)w->user_data();
    app->removeVoice(id);
}

// ─────────────────────────────────────────────────────────────────────────────
int main(int argc, char** argv) {
    // Request FLTK lock for threaded use
    Fl::lock();

    HarmoniaApp app;
    app.run();
    return 0;
}
