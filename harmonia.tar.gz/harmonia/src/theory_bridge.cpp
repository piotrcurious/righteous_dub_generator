#include "theory_bridge.h"
#include <unistd.h>
#include <sys/wait.h>
#include <sys/select.h>
#include <cstring>
#include <sstream>
#include <cassert>
#include <algorithm>
#include <stdio.h>
#include <errno.h>

TheoryBridge::TheoryBridge() {}

TheoryBridge::~TheoryBridge() { stop(); }

// ────────────────────────────────────────────────────────────────────────────
bool TheoryBridge::start(const std::string& theory_dir) {
    if (pipe(to_py_) < 0 || pipe(from_py_) < 0) {
        perror("pipe"); return false;
    }

    py_pid_ = fork();
    if (py_pid_ < 0) { perror("fork"); return false; }

    if (py_pid_ == 0) {
        // ── child: become the Python server
        dup2(to_py_[0],   STDIN_FILENO);
        dup2(from_py_[1], STDOUT_FILENO);
        close(to_py_[0]);  close(to_py_[1]);
        close(from_py_[0]); close(from_py_[1]);

        std::string server = theory_dir + "/server.py";
        execl("/usr/bin/python3", "python3", server.c_str(), nullptr);
        perror("execl"); _exit(1);
    }

    // ── parent: close unused ends
    close(to_py_[0]); close(from_py_[1]);
    to_py_[0] = -1; from_py_[1] = -1;

    running_.store(true);
    reader_thread_ = std::thread(&TheoryBridge::readerLoop, this);
    fprintf(stderr, "TheoryBridge: Python pid=%d started\n", py_pid_);
    return true;
}

void TheoryBridge::stop() {
    running_.store(false);
    if (py_pid_ > 0) {
        kill(py_pid_, SIGTERM);
        waitpid(py_pid_, nullptr, 0);
        py_pid_ = -1;
    }
    if (to_py_[1] >= 0)   { close(to_py_[1]);   to_py_[1] = -1; }
    if (from_py_[0] >= 0) { close(from_py_[0]); from_py_[0] = -1; }
    if (reader_thread_.joinable()) reader_thread_.join();
}

// ────────────────────────────────────────────────────────────────────────────
//  Reader thread: reads newline-delimited JSON from Python stdout
// ────────────────────────────────────────────────────────────────────────────
void TheoryBridge::readerLoop() {
    char buf[65536];
    std::string acc;
    while (running_.load()) {
        // Use select with 50ms timeout so we can check running_ flag
        fd_set fds; FD_ZERO(&fds); FD_SET(from_py_[0], &fds);
        struct timeval tv{0, 50000};
        int r = select(from_py_[0]+1, &fds, nullptr, nullptr, &tv);
        if (r <= 0) continue;

        ssize_t n = read(from_py_[0], buf, sizeof(buf)-1);
        if (n <= 0) { running_.store(false); break; }
        buf[n] = '\0';
        acc += buf;

        // split on newlines
        size_t pos;
        while ((pos = acc.find('\n')) != std::string::npos) {
            std::string line = acc.substr(0, pos);
            acc.erase(0, pos+1);
            if (!line.empty()) {
                std::lock_guard<std::mutex> lk(response_mutex_);
                responses_.push_back(std::move(line));
            }
        }
    }
}

// ────────────────────────────────────────────────────────────────────────────
void TheoryBridge::sendRaw(const std::string& json) {
    if (to_py_[1] < 0 || !running_.load()) return;
    std::string msg = json + "\n";
    ssize_t n = write(to_py_[1], msg.c_str(), msg.size());
    (void)n;
}

// ────────────────────────────────────────────────────────────────────────────
//  poll() — call from FLTK idle to dispatch responses → callbacks
// ────────────────────────────────────────────────────────────────────────────
void TheoryBridge::poll() {
    std::deque<std::string> local;
    { std::lock_guard<std::mutex> lk(response_mutex_); local.swap(responses_); }

    for (auto& resp : local) {
        std::string tag = extractString(resp, "result");
        // Find matching pending callback
        std::lock_guard<std::mutex> lk(pending_mutex_);
        for (auto it = pending_cbs_.begin(); it != pending_cbs_.end(); ++it) {
            if (it->result_tag == tag) {
                auto cb = it->raw_cb;
                pending_cbs_.erase(it);
                if (cb) cb(resp);
                break;
            }
        }
    }
}

// ────────────────────────────────────────────────────────────────────────────
//  Synchronous query (for startup/one-shot use)
// ────────────────────────────────────────────────────────────────────────────
std::string TheoryBridge::sendSync(const std::string& json, int timeout_ms) {
    sendRaw(json);
    int waited = 0;
    while (waited < timeout_ms) {
        usleep(5000); waited += 5;
        std::lock_guard<std::mutex> lk(response_mutex_);
        if (!responses_.empty()) {
            std::string r = responses_.front();
            responses_.pop_front();
            return r;
        }
    }
    return "{}";
}

// ────────────────────────────────────────────────────────────────────────────
//  Public API — build JSON, register callback, send
// ────────────────────────────────────────────────────────────────────────────
void TheoryBridge::queryNextChords(int root, const std::string& type,
                                    int key_pc, int n, ChordsCb cb) {
    std::string json = "{\"cmd\":\"next_chords\","
        "\"root\":" + std::to_string(root) + ","
        "\"type\":\"" + type + "\","
        "\"key\":" + std::to_string(key_pc) + ","
        "\"n\":" + std::to_string(n) + "}";

    auto raw_cb = [cb](const std::string& resp) {
        // parse array: "chords":[{"root":7,"type":"maj","prob":0.35,"label":"G"}]
        std::vector<ChordSuggestion> results;
        // minimal JSON array parse
        size_t arr_start = resp.find("\"chords\"");
        if (arr_start == std::string::npos) { if(cb) cb(results); return; }
        arr_start = resp.find('[', arr_start);
        size_t arr_end = resp.find(']', arr_start);
        if (arr_start==std::string::npos||arr_end==std::string::npos) { if(cb) cb(results); return; }

        std::string arr = resp.substr(arr_start+1, arr_end-arr_start-1);
        // split by },{
        size_t pos = 0;
        while (pos < arr.size()) {
            size_t start = arr.find('{', pos);
            size_t end   = arr.find('}', start);
            if (start==std::string::npos||end==std::string::npos) break;
            std::string obj = arr.substr(start, end-start+1);
            ChordSuggestion cs;
            cs.root_pc     = extractInt(obj,"root",0);
            cs.type        = extractString(obj,"type","maj");
            cs.probability = extractFloat(obj,"prob",0.f);
            cs.label       = extractString(obj,"label","?");
            cs.delta_fifths= extractInt(obj,"df",0);
            cs.delta_thirds = extractInt(obj,"dt",0);
            results.push_back(cs);
            pos = end+1;
        }
        if (cb) cb(results);
    };

    { std::lock_guard<std::mutex> lk(pending_mutex_);
      pending_cbs_.push_back({"next_chords", raw_cb}); }
    sendRaw(json);
}

void TheoryBridge::querySuggestCompletion(const std::vector<int>& pcs,
                                           int key_pc, NotesCb cb) {
    std::string pcs_json = "[";
    for (size_t i = 0; i < pcs.size(); i++) {
        pcs_json += std::to_string(pcs[i]);
        if (i+1 < pcs.size()) pcs_json += ",";
    }
    pcs_json += "]";
    std::string json = "{\"cmd\":\"suggest_completion\","
        "\"pitch_classes\":" + pcs_json +
        ",\"key\":" + std::to_string(key_pc) + "}";

    auto raw_cb = [cb](const std::string& resp) {
        std::vector<NoteSuggestion> results;
        size_t arr_start = resp.find("\"suggestions\"");
        if (arr_start==std::string::npos) { if(cb) cb(results); return; }
        arr_start = resp.find('[', arr_start);
        size_t arr_end = resp.find(']', arr_start);
        if (arr_start==std::string::npos||arr_end==std::string::npos) { if(cb) cb(results); return; }
        std::string arr = resp.substr(arr_start+1, arr_end-arr_start-1);
        size_t pos = 0;
        while (pos < arr.size()) {
            size_t start = arr.find('{', pos);
            size_t end   = arr.find('}', start);
            if (start==std::string::npos||end==std::string::npos) break;
            std::string obj = arr.substr(start, end-start+1);
            NoteSuggestion ns;
            ns.pitch_class    = extractInt(obj,"pc",0);
            ns.name           = extractString(obj,"name","?");
            ns.score          = extractFloat(obj,"score",0.f);
            ns.roughness_delta= extractFloat(obj,"roughness_delta",0.f);
            ns.cents_ji       = extractFloat(obj,"cents_ji",0.f);
            results.push_back(ns);
            pos = end+1;
        }
        if (cb) cb(results);
    };

    { std::lock_guard<std::mutex> lk(pending_mutex_);
      pending_cbs_.push_back({"suggest_completion", raw_cb}); }
    sendRaw(json);
}

void TheoryBridge::queryOrbifoldDistance(const std::vector<int>& a,
                                          const std::vector<int>& b,
                                          OrbifoldCb cb) {
    auto mkArr = [](const std::vector<int>& v) {
        std::string s = "[";
        for (size_t i=0;i<v.size();i++) { s+=std::to_string(v[i]); if(i+1<v.size()) s+=","; }
        return s + "]";
    };
    std::string json = "{\"cmd\":\"orbifold_distance\","
        "\"chord_a\":" + mkArr(a) + ",\"chord_b\":" + mkArr(b) + "}";

    auto raw_cb = [cb](const std::string& resp) {
        OrbifoldDistance od;
        od.voice_leading_distance = extractFloat(resp,"distance",0.f);
        if (cb) cb(od);
    };

    { std::lock_guard<std::mutex> lk(pending_mutex_);
      pending_cbs_.push_back({"orbifold_distance", raw_cb}); }
    sendRaw(json);
}

void TheoryBridge::queryEDOAnalysis(int edo, RawJsonCb cb) {
    std::string json = "{\"cmd\":\"edo_analysis\",\"edo\":" + std::to_string(edo) + "}";
    auto raw_cb = [cb](const std::string& resp) { if(cb) cb(resp); };
    { std::lock_guard<std::mutex> lk(pending_mutex_);
      pending_cbs_.push_back({"edo_analysis", raw_cb}); }
    sendRaw(json);
}

// ────────────────────────────────────────────────────────────────────────────
//  Minimal JSON extraction (no external library)
// ────────────────────────────────────────────────────────────────────────────
int TheoryBridge::extractInt(const std::string& json, const std::string& key, int def) {
    std::string needle = "\"" + key + "\"";
    size_t p = json.find(needle);
    if (p == std::string::npos) return def;
    p = json.find_first_of("0123456789-", p + needle.size() + 1);
    if (p == std::string::npos) return def;
    return std::stoi(json.substr(p));
}

float TheoryBridge::extractFloat(const std::string& json, const std::string& key, float def) {
    std::string needle = "\"" + key + "\"";
    size_t p = json.find(needle);
    if (p == std::string::npos) return def;
    p = json.find_first_of("0123456789-.", p + needle.size() + 1);
    if (p == std::string::npos) return def;
    return std::stof(json.substr(p));
}

std::string TheoryBridge::extractString(const std::string& json, const std::string& key,
                                         const std::string& def) {
    std::string needle = "\"" + key + "\":\"";
    size_t p = json.find(needle);
    if (p == std::string::npos) return def;
    p += needle.size();
    size_t e = json.find('"', p);
    if (e == std::string::npos) return def;
    return json.substr(p, e-p);
}
